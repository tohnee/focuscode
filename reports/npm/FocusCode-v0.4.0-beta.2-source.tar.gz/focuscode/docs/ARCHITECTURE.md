# FocusCode v0.4 架构：会话 Agent 与审计 Kernel

FocusCode 当前保留两条明确的组合路径，共享安全原则和部分 primitive。v0.4 已把企业 allowlist、
物理 Sandbox、扩展策略和 HMAC audit 接入会话主路径；但 Tool effect 尚未全部经过 Kernel 的
Grant/Receipt/Verifier。这是当前架构事实，不是最终形态：正式企业版应共享唯一的 typed-intent
和 effect broker，同时允许低风险交互选择更轻的验证策略。

## 1. 两条执行路径

| 路径                        | 入口                                         | 优化目标                                 | 核心状态                                               |
| --------------------------- | -------------------------------------------- | ---------------------------------------- | ------------------------------------------------------ |
| Conversational Coding Agent | TUI / interactive / print / JSON / RPC / SDK | 低延迟、多轮探索、编辑与即时 steering    | Session tree、Context、Tool loop、Permission           |
| Audited Focus Kernel        | `focuscode run` / `createLocalHarness()`     | 可重放、Decision/Effect 分离、验证后完成 | TaskSpec、Checkpoint、Intent、Grant、Receipt、Verifier |

会话 Agent 在 `packages/agent-runtime`；审计 Kernel 在 `packages/harness-core`。两者都通过受控工具、
权限和明确完成条件工作，但当前不会把同一次调用同时写入两套状态机。

## 2. 分层

```mermaid
flowchart TD
    A["apps: CLI / APIs / workers"] --> C["composition: SDK"]
    C --> R["runtime: agent / kernel"]
    R --> D["domain: contracts / action / context"]
    C --> P["adapters: auth / providers / sandbox / TUI / ecosystem"]
    R --> S["state: session / persistence / assets"]
```

- `contracts` 无运行时 Provider、文件、Shell 或 UI 依赖；
- `harness-core` 不访问 fs、child_process、fetch 或具体 adapter；
- `agent-runtime` 不依赖 auth、sandbox、TUI、ecosystem 或 apps；
- auth/ecosystem/sandbox/TUI 是叶子 adapter，互不依赖 FocusCode core；
- CLI/SDK 是唯一允许组合这些模块的地方；
- `scripts/check-boundaries.mjs` 在 CI 强制上述方向。

## 3. Conversational Agent

核心对象：

- `CodingAgent`：单主循环、child model controller、SteeringQueue；
- `ModelClient`：四种原生协议的统一端口；
- `AgentToolRegistry`：内置和扩展工具注册；
- `PermissionController`：effect/path/shell/approval；
- `SessionStore`：append-only tree、fork、compaction、runtime validation；
- `ConversationContext`：active branch 和 token budget；
- `ExtensionHost`：可信进程内扩展；
- `ShellExecutor`：Host/Docker/gVisor/VM 可替换端口。

更完整的数据流、接口和约束见 [V0.3_CAPABILITY_ARCHITECTURE.md](V0.3_CAPABILITY_ARCHITECTURE.md)。

## 4. Audited Kernel

Kernel 仍遵循：

1. Model 只产生 `ModelDecisionV1`；
2. Policy 将 Action Intent 转为短期 Capability Grant；
3. Action Runtime 执行并产生 Effect Receipt；
4. Ledger 从 Receipt 汇总 changed files/risk；
5. Verifier 在 baseline/target 证据充分时允许 `REVIEW_READY`；
6. Checkpoint 和 Domain Events 支持任务恢复。

这条路径的长期目标是 durable outbox、unknown-effect reconciliation 和多 Worker fencing。当前
文件存储仍是 Alpha，不应作为跨主机 exactly-once 保证。

## 5. 组合根

CLI：

- 解析用户配置与显式 override；
- 从加密凭据库提供 access token callback；
- 创建 SandboxExecutor 并注入 Bash Tool；
- 加载通过签名策略的 npm Extension；
- 选择 TUI/interactive/print/JSON/RPC；
- 将图片和 session share 转换为 runtime 类型。

SDK 执行同样的 Sandbox 与 Extension 组合，同时允许企业注入自己的 `ShellExecutor`、
`accessTokenProvider`、approval callback 和 event sink。

## 6. 数据所有权

用户侧资产：Session JSONL、Compaction、OAuth account metadata/token、Extension lock、share
identity、项目指令和 Harness 配置。Provider 只收到当前请求所需上下文；Tool 子进程不收到
Provider Token。替换 Provider 不迁移或重置用户资产。

## 7. 运行时边界

- Bash 可进入物理 Sandbox；文件 primitive 在 Harness 进程但受 workspace/permission 控制；
- Provider/OAuth/Session/Extension Host 不在 Bash 容器；
- Extension 目前是可信进程内代码；
- 分享服务只存验签后的不可变 blob，不成为 Session 执行者；
- A2A/MCP/ACP 仍以 contract/boundary 为主，不在 v0.4 冒充完整认证网络实现。

## 8. 正式版收敛目标

1. `CodingAgent` 和 `FocusKernel` 共享 Policy → Grant → Started → Receipt 主链；
2. Provider adapter 只负责方言，所有 continuation state 进入 portable Session envelope；
3. Extension 与 A2A workload 通过 capability broker，不在 CLI 主进程获得 Node 全权限；
4. audit journal 记录不可抵赖的副作用元数据，Session 保存用户工作内容，两者不重复存储；
5. crash 后对未知 effect 做 reconciliation，再决定重试、补偿或人工接管。
