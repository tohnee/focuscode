# FocusCode v0.4 Beta2 开发进度

报告日期：2026-07-20  
版本：`0.4.0-beta.2`  
阶段判断：六项指定差距均已有可运行实现和自动化证据，但只有 mid-turn steering 可判断为
“基本关闭”。Provider live contract、真实隔离、Pi 同条件基准和扩展 containment 尚未通过，
因此当前是企业预生产 Beta，不是可无条件推广的生产正式版。

## 1. 交付规模

- 17 个 package、5 个 app/process entrypoint、1 个 root workspace；
- 97 个非测试 TypeScript/MJS 源文件，约 16,749 行；
- 26 个测试文件、93 项测试，测试约 3,600 行；
- 10 个内置 Coding Tool；
- 4 个原生模型协议、Kimi/Qwen/GLM/DeepSeek/MiniMax 等 Provider profile 与模型级覆盖；
- TUI/interactive/print/JSON/RPC/SDK 六类接入；
- 5 个主题、6 只多状态终端伙伴，并支持经过校验的自定义 JSON；
- Host/Docker/gVisor/VM 四种 Sandbox backend 和 fail-closed auto selector；
- 252 项可校验源码 manifest（含 docs/reviews 与 reports/npm 制品）。

`dist`、npm bundle、`node_modules`、coverage HTML 和临时 clean-install 目录不计入源码规模。

## 2. 用户指定范围完成度

| Epic                      | 工程状态       | 已交付                                                                                                       | 剩余 Gate                                                     |
| ------------------------- | -------------- | ------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------- |
| OAuth 与五类模型          | Beta           | PKCE/device/OIDC/refresh/revoke/加密账号库；五系区域 profile；模型能力、reasoning、重试与 continuation state | 五家真实凭据 smoke、订阅 OAuth 官方授权、recorded stream 证书 |
| 全屏 TUI/主题/keymap/伙伴 | Beta           | alternate screen、差分更新、审批/历史/滚动、多行、5 主题、6 伙伴、自定义 JSON                                | Pi 级编辑器、autocomplete、IME、clipboard、Markdown/diff 组件 |
| 图片/多模态               | Beta           | 本地/HTTPS 图片、magic/digest/限制、四协议映射、模型能力 Gate、企业 egress deny                              | 剪贴板/拖入、音视频、真实视觉模型矩阵                         |
| 扩展分发/会话分享         | Beta           | npm exact/signature/integrity/lock；Ed25519 share；auth/trust/age/rate server                                | 扩展独立 capability host、撤销服务、OIDC/ACL/HA 存储          |
| Mid-turn steering         | Beta，基本关闭 | append/interrupt/follow-up FIFO、上限、TUI/RPC/SDK 一致                                                      | 队列取回与 one-at-a-time/all delivery mode                    |
| Docker/gVisor/VM          | 驱动完成       | digest pin、pull-never、无网络/IPC/log、资源限制、auto no-fallback、doctor                                   | 目标主机 adversarial CI、VM lifecycle/attestation             |
| npm 发布安装              | Beta           | standalone tarball、bin、clean install、安装后真实本地 tool loop                                             | npm scope 所有权与 registry 正式发布                          |

## 3. 本轮关键修复

- Provider 从“endpoint + protocol”升级为可版本化的 capability/compatibility/reliability profile；
- 修复 Session 校验丢弃 reasoning continuation state：OpenAI `reasoning_content` 与 Anthropic
  thinking/signature block 可完整持久化和工具轮回放，分享时无条件移除；
- Kimi K3、Qwen、GLM、DeepSeek V4、MiniMax M3 的 reasoning/tool 方言采用条件字段，不再粗暴
  共用同一 OpenAI-compatible payload；
- 引入有界网络/429/5xx 重试与 `Retry-After`，并输出可观测 retry event；
- 企业配置对 Provider、model、extension、remote media、Sandbox 和 audit fail-closed；
- HMAC-SHA-256 链式审计只记录摘要/大小等必要元数据，不复制 Prompt 或 Tool output；
- Share Server 默认认证，增加 constant-time token、可信 signer、最大年龄和限流；
- CLI/SDK 使用同一隔离和扩展策略，并由 `focuscode doctor` 汇总 readiness。

## 4. Apple-to-Apple 结论

| 维度                                      | 当前领先方 | 判断                                                    |
| ----------------------------------------- | ---------- | ------------------------------------------------------- |
| 个人终端 UX、Provider 目录、会话/扩展生态 | Pi         | Pi 0.80.10 更成熟，FocusCode 尚未达到其编辑器和生态深度 |
| 默认权限、保护路径、隔离 fail-closed      | FocusCode  | 架构和代码更完整，但真实基础设施 Gate 未跑完            |
| 企业审计与允许列表                        | FocusCode  | HMAC 链、模型/扩展/media policy 是明确差异化            |
| Compaction、长期稳定性、实战证据          | Pi         | FocusCode 缺长期使用和同模型 Repo A/B 证据              |
| 总体 Coding 成功率                        | 未证实     | 没有相同模型、预算、仓库和验收脚本的数据，不能宣称领先  |

完整逐项证据见 [V0.4_PI_APPLE_TO_APPLE_REVIEW.md](V0.4_PI_APPLE_TO_APPLE_REVIEW.md)。

## 5. 原工程 Epic 映射

| Epic                    | 当前状态     | 说明                                                                    |
| ----------------------- | ------------ | ----------------------------------------------------------------------- |
| E01 Canonical Contracts | Beta         | 11 Schema、digest、ports、strict validation                             |
| E02 Focus Kernel        | Alpha/Beta   | 状态、预算、atomic rejection、checkpoint、verification gate             |
| E03 Action Runtime      | 部分         | 本地 Policy/Receipt/Ledger；无 durable reconciliation/remote auth       |
| E04 Event/Asset         | 部分         | File Fact/Checkpoint/Memory/Session/share；无 PostgreSQL/outbox         |
| E05 Model Gateway       | Beta，两路径 | 审计 JSON Pack + 会话四协议 native streaming；主链尚未统一              |
| E06/E07 Open Model Pack | Beta profile | 五系 profile/方言；无 live revision 质量证书                            |
| E08 Context             | 部分         | branch/compaction/multimodal/provider state；无 symbol/LSP retrieval    |
| E09 Edit/Verify         | 部分         | edit/patch/bash/git；无 affected-test planner/LSP                       |
| E10 CLI                 | Beta         | 六入口、TUI、OAuth、多模态、npm；无 VS Code/ACP client                  |
| E11 Enterprise Memory   | 基础         | asset/share/audit；未接长期 retrieval/ranking                           |
| E12 Protocol Gateways   | 合约级       | MCP/ACP/A2A 非完整认证网络实现                                          |
| E13 Native Capsules     | 未开始       | manifest classification，无 signed runtime capsule                      |
| E14 FocusBench          | 测试底座     | 无真实多模型 Repo 矩阵/证书                                             |
| E15 SRE/Release         | Beta         | CI/coverage/npm/doctor；无 SBOM/canary/SLO/production image attestation |

## 6. Stop conditions

- 目标平台未实跑 physical Sandbox 前，不宣称可安全执行不可信仓库；
- Extension 未进独立 capability sandbox 前，不开放默认自动安装的公共市场；
- 无 durable receipt/reconciliation 前，不开放多 Worker 自动写和高价值外部副作用；
- 无组织身份/ACL/retention 前，不把 Share Server 当成公共多租户服务；
- 无真实同模型 A/B 前，不宣称总体优于 Pi；
- npm scope 未由 Owner 正式发布前，只承诺 tarball clean install。

## 7. 下一阶段优先级

1. 合并 CodingAgent Permission 与 FocusKernel Policy/Grant/Receipt，形成唯一副作用主链；
2. 五系 Provider recorded streams、live smoke 与固定模型 revision 证书；
3. Docker/runsc CI 攻击矩阵和 disposable VM provision/attest/destroy；
4. Extension process/WASI capability host；
5. Session WAL/checksum/migration/repair 与 Effect reconciliation；
6. Pi 10–30 Repo 同模型 A/B、24h soak 和性能预算；
7. Pi 级终端 editor、autocomplete、diff review、compaction 与 LSP retrieval。
