# FocusCode v0.4 Beta1 企业接入与发布 Gate

本文给出 `0.4.0-beta.1` 的最小可用接入、五类 Provider 配置、安全默认值和正式上线门禁。

## 1. 安装

```bash
npm install --global ./focuscode-cli-0.4.0-beta.1.tgz
focuscode --version
```

最低 Node.js：`22.12.0`。从源码验证：

```bash
corepack enable
corepack prepare pnpm@11.7.0 --activate
pnpm install --frozen-lockfile
pnpm release:check
```

## 2. 五类 Provider 快速接入

| Provider ID            | 默认协议           | 默认模型           | 环境变量            | 区域                            |
| ---------------------- | ------------------ | ------------------ | ------------------- | ------------------------------- |
| `kimi`                 | OpenAI Chat        | `kimi-k3`          | `MOONSHOT_API_KEY`  | Global                          |
| `kimi-cn` / `moonshot` | OpenAI Chat        | `kimi-k3`          | `MOONSHOT_API_KEY`  | China                           |
| `kimi-coding`          | Anthropic Messages | `k3`               | `KIMI_API_KEY`      | Kimi Code subscription endpoint |
| `qwen`                 | OpenAI Chat        | `qwen3-coder-plus` | `DASHSCOPE_API_KEY` | China                           |
| `qwen-intl`            | OpenAI Chat        | `qwen3-coder-plus` | `DASHSCOPE_API_KEY` | International                   |
| `glm`                  | OpenAI Chat        | `glm-5.2`          | `ZAI_API_KEY`       | Global                          |
| `glm-cn`               | OpenAI Chat        | `glm-5.2`          | `ZAI_API_KEY`       | China                           |
| `deepseek`             | OpenAI Chat        | `deepseek-v4-pro`  | `DEEPSEEK_API_KEY`  | Global                          |
| `minimax`              | Anthropic Messages | `MiniMax-M3`       | `MINIMAX_API_KEY`   | Global                          |
| `minimax-cn`           | Anthropic Messages | `MiniMax-M3`       | `MINIMAX_API_KEY`   | China                           |

示例：

```bash
export DEEPSEEK_API_KEY=...
focuscode --provider deepseek --sandbox docker "修复测试并解释验证结果"

export DASHSCOPE_API_KEY=...
focuscode --model qwen/qwen3-coder-plus "审查当前改动"
```

内置模型 ID 是可覆盖默认值。生产必须按已采购的实际模型 revision 配置，不应假定默认 alias
永久稳定。

## 3. 模型级能力覆盖

Provider 相同不代表模型能力相同。多模态、上下文、reasoning 和兼容字段可按
`provider/model` 覆盖：

```json
{
  "schemaVersion": "focuscode-agent.v1",
  "provider": "qwen",
  "model": "qwen-vl-max",
  "models": {
    "qwen/qwen-vl-max": {
      "contextWindow": 262144,
      "maxOutputTokens": 32768,
      "reasoningEffort": "high",
      "capabilities": {
        "input": ["text", "image"],
        "reasoning": true,
        "toolCalling": true
      },
      "compatibility": {
        "thinkingFormat": "qwen",
        "supportsReasoningEffort": true
      },
      "reliability": {
        "timeoutMs": 300000,
        "maxRetries": 3,
        "retryBaseDelayMs": 500,
        "retryMaximumDelayMs": 10000
      }
    }
  }
}
```

## 4. OAuth 与企业 OIDC

五类命名开源模型默认使用官方 API key。OAuth 只有在 Provider 官方提供并授权相应客户端时
才成立；FocusCode 不伪造厂商订阅协议。企业可通过标准 OIDC gateway：

```bash
export FOCUSCODE_ENTERPRISE_CLIENT_ID=focuscode-cli
export FOCUSCODE_ENTERPRISE_CLIENT_SECRET=...

focuscode auth login enterprise \
  --issuer https://identity.example.com \
  --scope openid,profile,offline_access,models \
  --account work
```

实现包含 discovery、PKCE loopback、device flow、refresh、client auth method negotiation、
revocation 和 AES-256-GCM 凭据存储。退出并撤销：

```bash
focuscode auth logout enterprise --account work --revoke
```

## 5. 企业配置模板

先构建并推送组织 Sandbox image，获取不可变 digest。然后：

```json
{
  "schemaVersion": "focuscode-agent.v1",
  "provider": "deepseek",
  "model": "deepseek-v4-pro",
  "approval": "ask",
  "sandbox": {
    "kind": "gvisor",
    "image": "registry.example.com/focuscode/node22@sha256:REPLACE_WITH_64_HEX_DIGEST",
    "network": "none",
    "allowHostFallback": false,
    "requireImageDigest": true
  },
  "media": {
    "allowRemoteImages": false
  },
  "enterprise": {
    "enabled": true,
    "allowedProviders": ["deepseek"],
    "allowedModels": ["deepseek/deepseek-v4-pro"],
    "requireIsolatedSandbox": true,
    "auditDirectory": "/var/lib/focuscode/audit",
    "auditHmacKeyEnv": "FOCUSCODE_AUDIT_HMAC_KEY",
    "allowProjectExtensions": false,
    "allowedExtensions": []
  },
  "requireExtensionSignatures": true,
  "tui": {
    "enabled": true,
    "title": "Acme FocusCode",
    "theme": "aurora",
    "mascot": "mochi",
    "keymap": {}
  }
}
```

企业模式会拒绝：

- 未允许的 Provider/model；
- Host Sandbox 或 Host fallback；
- 非 digest image；
- 远程图片 URL；
- unsigned extension、临时 `--extension` 和默认项目 extension；
- 缺失或短于 32 bytes 的审计 HMAC key。

设置审计 key 后运行 readiness check：

```bash
export FOCUSCODE_AUDIT_HMAC_KEY="$(openssl rand -base64 48)"
focuscode doctor --repo /workspace/project
```

只有输出 `"ready": true` 才进入任务 smoke test。

## 6. TUI、自定义主题与助手

内置主题：`aurora`、`candy`、`forest`、`midnight`、`mono`。  
内置伙伴：`mochi`、`byte`、`nori`、`pico`、`bubu`、`kumo`。

```bash
focuscode --theme candy --mascot pico
focuscode --theme .focuscode/team-theme.json \
  --mascot .focuscode/team-mascot.json
```

自定义文件会限制 ANSI 颜色、字符串控制字符、帧数、行数和宽度，避免终端注入和无界渲染。
伙伴有 `idle/thinking/working/happy/oops` 五种状态。

运行中：

- 普通 busy input：append steering；
- `/interrupt ...`：中断当前模型 generation 并立即转向；
- `/followup ...`：当前工作达到 final response 后再交付；
- `/image local.png`：给下一条消息加图；
- 企业模式只允许本地图片。

## 7. Extension 与分享

企业模式默认零扩展。只有经过组织评审、npm signature 验证并列入
`enterprise.allowedExtensions` 的包会加载。即使如此，v0.4 的 Extension 仍是进程内可信代码；
它不是安全沙箱。

分享 bundle 默认：

- 删除 Tool output 和图片；
- 对常见凭据做 best-effort redaction；
- Ed25519 签名；
- 下载/导入前验签。

Share Server 可配置 bearer auth、可信 signer fingerprint、TTL 和 rate limit。正式多租户部署
还需要组织 ACL、数据库、删除/retention、配额和滥用治理。

## 8. 发布 Gate

### 自动化 Gate

```bash
pnpm lint
pnpm test:coverage
pnpm demo
pnpm agent:demo
pnpm npm:verify
```

### 基础设施 Gate

1. 在目标 Linux 节点执行 Docker 和 runsc smoke；
2. 验证默认断网、Host HOME/Docker socket 不可见；
3. 测试 fork bomb、OOM、timeout、abort 和残留容器；
4. VM 路径必须完成 provision → attest → execute → destroy；
5. image 必须有 SBOM、签名、漏洞策略和 digest pin。

### Provider Gate

每个批准模型至少验证：text stream、reasoning、单/并行 tools、tool continuation、长输出、
429 Retry-After、abort、图片（如声明）、usage 和 context overflow。保存脱敏 recorded stream 作为
后续回归 fixture。

### 质量 Gate

对 Pi 使用同一模型和预算运行 10–30 个固定 Repo 任务，至少记录：成功率、首次正确修改、
无效 Tool call、token、wall time、重试、人工干预、越权尝试和验证通过率。没有该 Gate 不宣称
总体质量领先。

## 9. 当前不能承诺

- 本交付环境没有真实 Docker/runsc/远端 disposable VM 证据；
- 没有外部 Provider 凭据，因此没有五家 live API smoke；
- Extension 尚未 capability-contained；
- Conversational Agent 与 deterministic Focus Kernel 尚未使用完全相同的 Effect Receipt 主链；
- Session JSONL 尚无数据库级 WAL/exactly-once；
- `@focuscode/cli` tarball 可安装，但 npm scope 是否已由 Owner 发布不在代码证明范围内。
