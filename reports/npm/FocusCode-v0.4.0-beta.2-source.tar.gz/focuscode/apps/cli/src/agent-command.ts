import { createHash } from "node:crypto";
import { homedir } from "node:os";
import { join, resolve } from "node:path";
import { writeFile } from "node:fs/promises";
import {
  CodingAgent,
  ExtensionHost,
  FileAuditJournal,
  SessionStore,
  createCodingToolRegistry,
  createModelClient,
  expandFileMentions,
  listProviderPresets,
  loadImageAttachments,
  loadAgentResources,
  renderResourcePrompt,
  renderSessionHtml,
  resolveAgentConfig,
  type AgentConfigOverrides,
  type ModelProfile,
  type ResolvedAgentConfig,
} from "@focuscode/agent-runtime";
import { ExtensionPackageManager } from "@focuscode/ecosystem";
import { createSandbox } from "@focuscode/sandbox";
import { parseAgentArgs, type AgentCliArgs } from "./agent-args.js";
import { oauthAccessTokenProvider } from "./auth-command.js";
import { HumanEventRenderer, jsonEventWriter, promptApproval, shortId } from "./agent-output.js";
import { runInteractive, TerminalPrompter } from "./interactive.js";
import { rpcEventSink, runRpc } from "./rpc.js";
import { defaultExtensionDirectory } from "./platform-command.js";
import { runFullScreenAgent } from "./tui.js";

export const CLI_VERSION = "0.4.0-beta.2";

export function isAgentInvocation(argv: string[]): boolean {
  const first = argv[0];
  return (
    !first ||
    ![
      "init",
      "run",
      "inspect",
      "export",
      "auth",
      "extension",
      "share",
      "sandbox",
      "mascots",
      "themes",
      "doctor",
    ].includes(first)
  );
}

export async function runAgentCommand(argv: string[]): Promise<void> {
  const args = parseAgentArgs(argv);
  if (args.help) {
    printAgentHelp();
    return;
  }
  if (args.version) {
    process.stdout.write(`${CLI_VERSION}\n`);
    return;
  }
  if (args.listProviders) {
    printProviders();
    return;
  }
  const cwd = resolve(args.cwd);
  const sessionDirectory = resolve(args.sessionDirectory ?? defaultSessionDirectory(cwd));
  const sessions = new SessionStore(sessionDirectory, !args.noSession);
  if (args.listSessions) {
    printSessionList(await sessions.list(cwd));
    return;
  }
  if (args.exportSession) {
    if (!args.session) throw new Error("--export-session requires --session <id>");
    const snapshot = await sessions.load(args.session);
    const output = resolve(args.exportSession);
    await writeFile(output, renderSessionHtml(snapshot), "utf8");
    process.stdout.write(`Exported ${output}\n`);
    return;
  }

  const modelSpec = splitModelSpec(args.model, args.provider);
  const config = await resolveAgentConfig(cwd, configOverrides(args, modelSpec));
  let mode = args.mode;
  if (!args.modeExplicit && mode === "tui" && config.tui.enabled === false) {
    mode = "interactive";
  }
  if ((mode === "interactive" || mode === "tui") && !process.stdin.isTTY) mode = "print";
  const effectiveApproval =
    config.approval === "ask" && !process.stdin.isTTY ? "deny" : config.approval;
  if (effectiveApproval !== config.approval) {
    process.stderr.write(
      "Non-interactive input cannot answer approvals; approval mode changed from ask to deny. Use --approval auto-edit or full-auto explicitly.\n",
    );
  }

  const resources = await loadAgentResources({
    cwd,
    projectTrusted: config.projectTrusted,
    configuredInstructions: config.instructions,
  });
  const sandbox = await createSandbox({
    kind: config.sandbox.kind ?? "auto",
    workspaceRoot: cwd,
    ...(config.sandbox.image ? { image: config.sandbox.image } : {}),
    ...(config.sandbox.network ? { network: config.sandbox.network } : {}),
    ...(config.sandbox.requireImageDigest ? { requireImageDigest: true } : {}),
    ...(config.sandbox.allowHostFallback ? { allowHostFallback: true } : {}),
    ...(config.sandbox.vmHost && config.sandbox.vmWorkspace
      ? {
          vm: {
            host: config.sandbox.vmHost,
            remoteWorkspace: config.sandbox.vmWorkspace,
            ...(config.sandbox.vmIdentityFile
              ? { identityFile: config.sandbox.vmIdentityFile }
              : {}),
          },
        }
      : {}),
  });
  if (sandbox.kind === "host") {
    process.stderr.write(
      "Warning: Bash is running as a protected host subprocess, not in OS isolation. Prefer --sandbox auto, gvisor, docker, or vm for untrusted code.\n",
    );
  }
  const registry = await createCodingToolRegistry(cwd, { shellExecutor: sandbox });
  const enabled = new Set(
    args.tools ?? config.enabledTools ?? registry.definitions().map((tool) => tool.name),
  );
  const disabled = new Set([...config.disabledTools, ...args.excludeTools]);
  for (const tool of registry.definitions()) {
    if (!enabled.has(tool.name) || disabled.has(tool.name)) registry.unregister(tool.name);
  }
  const extensions = new ExtensionHost(registry);
  const extensionPackages = new ExtensionPackageManager({
    directory: resolve(config.extensionDirectory ?? defaultExtensionDirectory()),
  });
  const extensionPaths = await allowedExtensionPaths(extensionPackages, config);
  if (config.enterprise.enabled && args.extensionPaths.length > 0) {
    throw new Error("Enterprise policy forbids ad-hoc --extension paths");
  }
  await extensions.load([
    ...extensionPaths,
    ...(config.enterprise.enabled && !config.enterprise.allowProjectExtensions
      ? []
      : resources.extensionPaths),
    ...args.extensionPaths.map((path) => resolve(path)),
  ]);
  const tools = registry.values();
  if (tools.length === 0 && !args.tools?.includes("none")) {
    process.stderr.write("Warning: no tools are enabled; the agent can only respond with text.\n");
  }

  let sessionId = await selectSession(args, sessions, cwd, config.model);
  const prompter =
    process.stdin.isTTY && mode === "interactive" ? new TerminalPrompter() : undefined;
  const client = modelClientFor(config.model);
  const renderer = new HumanEventRenderer({
    quietTools: mode === "print" && !process.stderr.isTTY,
  });
  const eventSink =
    mode === "json"
      ? jsonEventWriter()
      : mode === "rpc"
        ? rpcEventSink
        : (event: Parameters<HumanEventRenderer["handle"]>[0]) => renderer.handle(event);
  let tuiApproval: ((question: string) => Promise<boolean>) | undefined;
  const auditJournal = enterpriseAuditJournal(config);
  const agent = await CodingAgent.create({
    cwd,
    model: config.model,
    modelClient: client,
    tools,
    toolRegistry: registry,
    permission: {
      mode: effectiveApproval,
      projectTrusted: config.projectTrusted,
      protectedPaths: config.protectedPaths,
      ...(mode === "tui"
        ? {
            approve: (request) =>
              tuiApproval?.(
                request.tool.name + " · risk " + request.risk + " · " + request.reason,
              ) ?? Promise.resolve(false),
          }
        : prompter
          ? { approve: (request) => promptApproval(request, (question) => prompter.ask(question)) }
          : {}),
    },
    sessionStore: sessions,
    ...(sessionId ? { sessionId } : {}),
    ...(args.name && !sessionId ? { sessionName: args.name } : {}),
    instructions: [renderResourcePrompt(resources)],
    maxRounds: args.maxRounds ?? config.maxRounds,
    steeringMaximum: config.steeringMaximum,
    eventSink,
    extensionHost: extensions,
    ...(auditJournal ? { auditJournal } : {}),
  });
  sessionId = agent.sessionId;
  if (args.name && (args.session || args.continueSession || args.resume || args.fork)) {
    await agent.nameSession(args.name);
  }

  const stdinText = mode === "rpc" ? "" : await readPipedInput();
  const rawPrompt = [stdinText, args.promptParts.join(" ")].filter(Boolean).join("\n\n");
  const initialPrompt = rawPrompt ? await expandFileMentions(cwd, rawPrompt) : undefined;
  const initialAttachments = await loadImageAttachments(args.imagePaths, {
    cwd,
    allowOutsideWorkspace: true,
    allowRemoteUrls: config.media.allowRemoteImages ?? true,
  });
  const changeModel = async (spec: string): Promise<ModelProfile> => {
    const parsed = splitModelSpec(spec, undefined);
    const next = await resolveAgentConfig(cwd, {
      ...configOverrides(args, parsed),
      projectTrusted: config.projectTrusted,
    });
    await agent.changeModel(next.model, modelClientFor(next.model));
    return next.model;
  };

  try {
    if (mode === "tui") {
      await runFullScreenAgent({
        agent,
        sessions,
        resources,
        extensions,
        cwd,
        model: config.model,
        approval: effectiveApproval,
        sandbox: sandbox.kind,
        title: config.tui.title ?? "FocusCode",
        theme: args.theme ?? config.tui.theme ?? "aurora",
        mascot: args.mascot ?? config.tui.mascot ?? "mochi",
        keymap: config.tui.keymap ?? {},
        allowRemoteImages: config.media.allowRemoteImages ?? true,
        ...(args.keymapPath ? { keymapPath: args.keymapPath } : {}),
        ...(initialPrompt ? { initialPrompt } : {}),
        ...(initialAttachments.length ? { initialAttachments } : {}),
        changeModel,
        onReady: (tui) => {
          tuiApproval = (question) => tui.requestApproval(question);
        },
      });
      return;
    }
    if (mode === "interactive") {
      if (!prompter) throw new Error("Interactive mode requires a TTY");
      await runInteractive({
        agent,
        sessions,
        resources,
        extensions,
        prompter,
        ...(initialPrompt ? { initialPrompt } : {}),
        changeModel,
      });
      return;
    }
    if (mode === "rpc") {
      if (initialPrompt) await agent.submit(initialPrompt);
      await runRpc(agent, sessions);
      return;
    }
    if (!initialPrompt) throw new Error(`${mode} mode requires a prompt or piped stdin`);
    const result = await agent.submit({
      text: initialPrompt,
      ...(initialAttachments.length ? { attachments: initialAttachments } : {}),
    });
    renderer.finishLine();
    if (["max_rounds", "length", "error"].includes(result.stopped)) process.exitCode = 2;
  } finally {
    prompter?.close();
  }
}

async function selectSession(
  args: AgentCliArgs,
  sessions: SessionStore,
  cwd: string,
  model: ModelProfile,
): Promise<string | undefined> {
  if (args.fork) {
    const separator = args.fork.indexOf(":");
    const sourceId = separator >= 0 ? args.fork.slice(0, separator) : args.fork;
    const entryId = separator >= 0 ? args.fork.slice(separator + 1) : undefined;
    return (await sessions.fork(sourceId, entryId, model, args.name)).header.sessionId;
  }
  if (args.session) return (await sessions.load(args.session)).header.sessionId;
  if (args.continueSession) return (await sessions.latest(cwd))?.sessionId;
  if (args.resume) {
    const available = await sessions.list(cwd);
    if (available.length === 0) throw new Error("No sessions found for this workspace");
    if (!process.stdin.isTTY) return available[0]!.sessionId;
    process.stdout.write(
      available
        .slice(0, 20)
        .map(
          (session, index) =>
            `${index + 1}. ${session.name ?? shortId(session.sessionId)} — ${session.preview}`,
        )
        .join("\n") + "\n",
    );
    const selector = new TerminalPrompter();
    try {
      const answer = await selector.ask("Resume session number: ");
      const index = Number(answer) - 1;
      if (!Number.isInteger(index) || !available[index])
        throw new Error("Invalid session selection");
      return available[index]!.sessionId;
    } finally {
      selector.close();
    }
  }
  return undefined;
}

function configOverrides(
  args: AgentCliArgs,
  modelSpec: { provider?: string; model?: string },
): AgentConfigOverrides {
  return {
    ...(modelSpec.provider ? { provider: modelSpec.provider } : {}),
    ...(modelSpec.model ? { model: modelSpec.model } : {}),
    ...(args.protocol ? { protocol: args.protocol } : {}),
    ...(args.baseUrl ? { baseUrl: args.baseUrl } : {}),
    ...(args.apiKey ? { apiKey: args.apiKey } : {}),
    ...(args.apiKeyEnv ? { apiKeyEnv: args.apiKeyEnv } : {}),
    ...(args.authType ? { authType: args.authType } : {}),
    ...(args.oauthAccount ? { oauthAccount: args.oauthAccount } : {}),
    ...(args.contextWindow !== undefined ? { contextWindow: args.contextWindow } : {}),
    ...(args.maxOutputTokens !== undefined ? { maxOutputTokens: args.maxOutputTokens } : {}),
    ...(args.temperature !== undefined ? { temperature: args.temperature } : {}),
    ...(args.toolMode ? { toolMode: args.toolMode } : {}),
    ...(args.approval ? { approval: args.approval } : {}),
    ...(args.maxRounds !== undefined ? { maxRounds: args.maxRounds } : {}),
    ...(args.tools ? { enabledTools: args.tools } : {}),
    ...(args.excludeTools.length ? { disabledTools: args.excludeTools } : {}),
    ...(args.sandbox ||
    args.sandboxImage ||
    args.sandboxNetwork ||
    args.allowHostFallback ||
    args.vmHost ||
    args.vmWorkspace ||
    args.vmIdentity
      ? {
          sandbox: {
            ...(args.sandbox ? { kind: args.sandbox } : {}),
            ...(args.sandboxImage ? { image: args.sandboxImage } : {}),
            ...(args.sandboxNetwork ? { network: args.sandboxNetwork } : {}),
            ...(args.allowHostFallback ? { allowHostFallback: true } : {}),
            ...(args.vmHost ? { vmHost: args.vmHost } : {}),
            ...(args.vmWorkspace ? { vmWorkspace: args.vmWorkspace } : {}),
            ...(args.vmIdentity ? { vmIdentityFile: args.vmIdentity } : {}),
          },
        }
      : {}),
    ...(args.theme || args.mascot
      ? {
          tui: {
            ...(args.theme ? { theme: args.theme } : {}),
            ...(args.mascot ? { mascot: args.mascot } : {}),
          },
        }
      : {}),
    projectTrusted: args.trustProject,
  };
}

function modelClientFor(model: ModelProfile) {
  const accessTokenProvider = oauthAccessTokenProvider(model);
  return createModelClient({
    ...model,
    ...(accessTokenProvider ? { accessTokenProvider } : {}),
  });
}

function splitModelSpec(
  model: string | undefined,
  provider: string | undefined,
): { provider?: string; model?: string } {
  if (!model) return provider ? { provider } : {};
  const separator = model.indexOf("/");
  if (!provider && separator > 0) {
    return { provider: model.slice(0, separator), model: model.slice(separator + 1) };
  }
  return { ...(provider ? { provider } : {}), model };
}

async function readPipedInput(): Promise<string> {
  if (process.stdin.isTTY) return "";
  const chunks: Buffer[] = [];
  let bytes = 0;
  for await (const chunk of process.stdin) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(String(chunk));
    bytes += buffer.length;
    if (bytes > 5_000_000) throw new Error("Piped stdin exceeds 5 MB");
    chunks.push(buffer);
  }
  return Buffer.concat(chunks).toString("utf8").trim();
}

function defaultSessionDirectory(cwd: string): string {
  const digest = createHash("sha256").update(resolve(cwd)).digest("hex").slice(0, 16);
  return join(homedir(), ".focuscode", "sessions", digest);
}

async function allowedExtensionPaths(
  manager: ExtensionPackageManager,
  config: ResolvedAgentConfig,
): Promise<string[]> {
  const installed = await manager.list();
  if (!config.enterprise.enabled) {
    if (config.requireExtensionSignatures) {
      const unsigned = installed.filter((extension) => !extension.signed);
      if (unsigned.length > 0) {
        throw new Error(
          "Unsigned extensions are disabled: " + unsigned.map((item) => item.name).join(", "),
        );
      }
    }
    return installed.map((extension) => extension.entryPath);
  }
  const allowed = new Set(config.enterprise.allowedExtensions ?? []);
  return installed
    .filter((extension) => allowed.has(extension.name))
    .map((extension) => {
      if (!extension.signed) throw new Error(`Enterprise extension is unsigned: ${extension.name}`);
      const privileged = (extension.manifest.permissions ?? []).filter((permission) =>
        ["network", "shell"].includes(permission),
      );
      if (privileged.length > 0) {
        throw new Error(
          `Enterprise extension ${extension.name} requests privileged permission(s): ${privileged.join(", ")}`,
        );
      }
      return extension.entryPath;
    });
}

function enterpriseAuditJournal(config: ResolvedAgentConfig): FileAuditJournal | undefined {
  if (!config.enterprise.enabled) return undefined;
  const keyEnvironment = config.enterprise.auditHmacKeyEnv ?? "FOCUSCODE_AUDIT_HMAC_KEY";
  const key = process.env[keyEnvironment];
  if (!key) {
    throw new Error(`Enterprise mode requires a 32+ byte audit key in ${keyEnvironment}`);
  }
  return new FileAuditJournal({
    directory: config.enterprise.auditDirectory ?? join(homedir(), ".focuscode", "audit"),
    hmacKey: key,
  });
}

function printProviders(): void {
  process.stdout.write("Provider\tProtocol\tAPI key environment\tDefault base URL\n");
  for (const provider of listProviderPresets()) {
    process.stdout.write(
      `${provider.id}\t${provider.protocol}\t${provider.apiKeyEnv ?? "-"}\t${provider.baseUrl}\n`,
    );
  }
  process.stdout.write("custom\topenai-chat or anthropic-messages\tuser-defined\t--base-url\n");
}

function printSessionList(sessions: Awaited<ReturnType<SessionStore["list"]>>): void {
  for (const session of sessions) {
    process.stdout.write(
      `${session.sessionId}\t${session.updatedAt}\t${session.model}\t${session.name ?? ""}\t${session.preview}\n`,
    );
  }
}

export function printAgentHelp(): void {
  process.stdout.write(`FocusCode CLI Coding Agent ${CLI_VERSION}

Usage:
  focuscode [options] [@files...] [prompt...]
  focuscode -p [options] "fix the failing tests"
  focuscode --mode json [options] "review this repository"
  focuscode --mode rpc [options]

Model:
  --provider ID               Built-in or configured provider
  --model [PROVIDER/]ID       Model ID; provider prefix is optional
  --base-url URL              Override provider API base URL
  --protocol PROTOCOL         openai-responses | openai-chat | anthropic-messages | google-gemini
  --api-key KEY               In-memory override; prefer environment variables
  --oauth-account NAME        Use an encrypted OAuth account from focuscode auth login
  --auth-type TYPE            api-key | bearer | none
  --context-window N          Context window used for compaction
  --max-output-tokens N       Per-response output budget
  --tool-mode MODE            native | prompt-json | auto
  --list-providers            List built-in provider presets

Execution:
  -p, --print                 Run once and exit
  --mode MODE                 tui | interactive | print | json | rpc
  -i, --image PATH_OR_URL     Attach an image; repeat for multiple images
  --theme ID                  aurora | candy | forest | midnight | mono
  --mascot ID                 mochi | byte | nori | pico | bubu | kumo
  --keymap FILE               JSON key binding overrides
  --approval MODE             ask | auto-edit | full-auto | deny
  --trust-project             Load .focuscode instructions, skills and extensions
  -t, --tools LIST            Tool allowlist
  --exclude-tools LIST        Tool denylist
  --max-rounds N              Maximum model/tool rounds per user turn
  -e, --extension PATH        Load an explicit JavaScript extension

Isolation:
  --sandbox KIND              host | docker | gvisor | vm | auto
  --sandbox-image IMAGE       Container image with repository toolchains
  --sandbox-network MODE      none | bridge
  --vm-host HOST              SSH target for a pre-provisioned VM/microVM
  --vm-workspace PATH         Shared workspace path inside the VM
  --vm-identity PATH          SSH identity file
  --allow-host-fallback       Allow auto mode to fall back without OS isolation

Sessions:
  -c, --continue              Continue the most recent workspace session
  -r, --resume                Select a saved session
  --session ID                Resume a session by ID or unique prefix
  --fork ID[:ENTRY]           Fork a session or an earlier entry
  --session-dir PATH          Override session storage
  --no-session                Keep this invocation in memory only
  -n, --name NAME             Name the session
  --list-sessions             List sessions for the current workspace
  --session ID --export-session FILE

Compatibility commands from Harness Alpha remain available:
  focuscode init | run | inspect | export
`);
}
