import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import {
  activeBranch,
  expandPromptTemplate,
  loadImageAttachment,
  renderSessionHtml,
  type AgentAttachment,
  type AgentEvent,
  type AgentResources,
  type ApprovalMode,
  type CodingAgent,
  type ExtensionHost,
  type ModelProfile,
  type SessionStore,
} from "@focuscode/agent-runtime";
import {
  FullScreenTui,
  getMascot,
  getTheme,
  mergeKeymap,
  validateTuiMascot,
  validateTuiTheme,
  type TuiKeymap,
  type TuiMascot,
  type TuiTheme,
} from "@focuscode/tui";

export interface FullScreenAgentOptions {
  agent: CodingAgent;
  sessions: SessionStore;
  resources: AgentResources;
  extensions: ExtensionHost;
  cwd: string;
  model: ModelProfile;
  approval: string;
  sandbox: string;
  title?: string;
  theme: string | TuiTheme;
  mascot: string | TuiMascot;
  allowRemoteImages?: boolean;
  keymap?: Record<string, string>;
  keymapPath?: string;
  initialPrompt?: string;
  initialAttachments?: AgentAttachment[];
  changeModel(spec: string): Promise<ModelProfile>;
  onReady?(tui: FullScreenTui): void;
}

export async function runFullScreenAgent(options: FullScreenAgentOptions): Promise<void> {
  const keymap = await loadKeymap(options.keymapPath, options.keymap);
  const theme = await loadTheme(options.theme, options.cwd);
  const mascot = await loadMascot(options.mascot, options.cwd);
  let pendingAttachments = [...(options.initialAttachments ?? [])];
  let activeModel = options.model;
  const tui = new FullScreenTui({
    input: process.stdin,
    output: process.stdout,
    title: options.title ?? "FocusCode",
    model: activeModel.provider + "/" + activeModel.model,
    session: options.agent.sessionId,
    approval: options.approval,
    sandbox: options.sandbox,
    theme,
    mascot,
    keymap,
    onSubmit: async (text) => {
      const attachments = pendingAttachments;
      pendingAttachments = [];
      tui.setAttachments([]);
      await options.agent.submit({
        text,
        ...(attachments.length ? { attachments } : {}),
      });
    },
    onSteer: async (text) => {
      const receipt = await options.agent.steer(text, "append");
      tui.setQueued(receipt.queueSize);
    },
    onAbort: () => {
      options.agent.abort();
    },
    onCommand: async (command) => {
      const [rawName, ...parts] = command.slice(1).split(/\s+/);
      const name = rawName?.toLowerCase() ?? "";
      const args = parts.join(" ");
      if (name === "exit" || name === "quit") {
        tui.dispose();
        return;
      }
      if (name === "help") return tuiHelp();
      if (name === "status") return JSON.stringify(await options.agent.status(), null, 2);
      if (name === "tools") {
        return options.agent
          .toolDefinitions()
          .map((tool) => tool.name.padEnd(16) + tool.effect.padEnd(8) + tool.description)
          .join("\n");
      }
      if (name === "compact") {
        const compacted = await options.agent.compact();
        return "Compacted " + compacted.droppedMessages + " messages.";
      }
      if (name === "interrupt") {
        if (!args) return "Usage: /interrupt <steering instruction>";
        const receipt = await options.agent.steer(args, "interrupt");
        tui.setQueued(receipt.queueSize);
        return "Interrupt steering queued.";
      }
      if (name === "followup" || name === "follow-up") {
        if (!args) return "Usage: /followup <instruction>";
        const receipt = await options.agent.steer(args, "follow-up");
        tui.setQueued(receipt.queueSize);
        return "Follow-up queued for after the current work completes.";
      }
      if (name === "image") {
        if (!args) return "Usage: /image <path-or-https-url> | /image clear";
        if (args === "clear") {
          pendingAttachments = [];
          tui.setAttachments([]);
          return "Pending images cleared.";
        }
        const attachment = await loadImageAttachment(args, {
          cwd: options.cwd,
          allowOutsideWorkspace: true,
          allowRemoteUrls: options.allowRemoteImages ?? true,
        });
        pendingAttachments.push(attachment);
        tui.setAttachments(pendingAttachments.map((item) => item.name));
        return "Attached " + attachment.name + " for the next prompt.";
      }
      if (name === "images") {
        return pendingAttachments.length
          ? pendingAttachments.map((item) => item.name + " · " + item.mediaType).join("\n")
          : "No pending images.";
      }
      if (name === "approval") {
        if (!isApprovalMode(args)) return "Usage: /approval ask|auto-edit|full-auto|deny";
        options.agent.changeApproval(args);
        tui.setApproval(args);
        return "Approval mode: " + args;
      }
      if (name === "model") {
        if (!args) return activeModel.provider + "/" + activeModel.model;
        activeModel = await options.changeModel(args);
        tui.setModel(activeModel.provider + "/" + activeModel.model);
        return "Model changed to " + activeModel.provider + "/" + activeModel.model;
      }
      if (name === "new") {
        const session = await options.agent.newSession(args || undefined);
        tui.setSession(session);
        return "Started session " + session;
      }
      if (name === "resume") {
        if (!args) return "Usage: /resume <session-id>";
        const session = await options.agent.switchSession(args);
        tui.setSession(session);
        return "Switched to " + session;
      }
      if (name === "fork") {
        const session = await options.agent.forkSession(args || undefined);
        tui.setSession(session);
        return "Forked into " + session;
      }
      if (name === "sessions") {
        return (await options.sessions.list(options.cwd))
          .map(
            (session) =>
              session.sessionId + " · " + (session.name ?? "unnamed") + " · " + session.preview,
          )
          .join("\n");
      }
      if (name === "tree") {
        const snapshot = options.agent.snapshot();
        const active = new Set(activeBranch(snapshot).map((entry) => entry.entryId));
        return snapshot.entries
          .map(
            (entry) =>
              (entry.entryId === snapshot.activeLeafId
                ? "*"
                : active.has(entry.entryId)
                  ? "│"
                  : "·") +
              " " +
              entry.entryId +
              " " +
              entry.message.role +
              " " +
              entry.message.content.replace(/\s+/g, " ").slice(0, 100),
          )
          .join("\n");
      }
      if (name === "export") {
        const path = resolve(args || "focuscode-session-" + options.agent.sessionId + ".html");
        await writeFile(path, renderSessionHtml(options.agent.snapshot()), "utf8");
        return "Exported " + path;
      }
      if (name === "reload") {
        return "Reloaded " + (await options.extensions.reload()).length + " extension(s).";
      }
      if (name === "skills") {
        return options.resources.skills.length
          ? options.resources.skills
              .map((skill) => "/" + skill.name + " — " + skill.description)
              .join("\n")
          : "No skills discovered.";
      }
      if (name === "skill") {
        const [skillName, ...skillArgs] = parts;
        const skill = options.resources.skills.find((item) => item.name === skillName);
        if (!skill) return "Unknown skill: " + (skillName ?? "");
        void tui.submitText(
          "Apply the following skill.\n\n" +
            skill.content +
            "\n\nRequest: " +
            (skillArgs.join(" ") || "Continue the current task."),
        );
        return;
      }
      const prompt = options.resources.prompts.find((item) => item.name === name);
      if (prompt) {
        void tui.submitText(expandPromptTemplate(prompt, args));
        return;
      }
      const extension = options.extensions.getCommand(name);
      if (extension) {
        const result = await extension.execute(args, {
          sessionId: options.agent.sessionId,
          cwd: options.cwd,
        });
        return result ?? undefined;
      }
      return "Unknown command: /" + name;
    },
  });
  options.onReady?.(tui);
  options.agent.setEventSink((event) => renderEvent(tui, event));
  tui.setAttachments(pendingAttachments.map((attachment) => attachment.name));
  const running = tui.run();
  if (options.initialPrompt) {
    await tui.submitText(options.initialPrompt).catch((error: unknown) => {
      tui.addMessage("system", error instanceof Error ? error.message : String(error));
    });
  }
  await running;
}

function renderEvent(tui: FullScreenTui, event: AgentEvent): void {
  if (event.type === "model_start") {
    tui.setMood("thinking");
    tui.setStatus("Model round " + event.round + " · " + event.model);
  } else if (event.type === "text_delta") {
    tui.appendAssistant(event.delta);
  } else if (event.type === "tool_start") {
    tui.setMood("working");
    tui.setStatus("Running " + event.call.name + "…");
  } else if (event.type === "tool_end") {
    tui.addMessage(
      "tool",
      event.call.name + " · " + event.durationMs + "ms\n" + event.result.content.slice(0, 4_000),
    );
    tui.setMood(event.result.isError ? "oops" : "happy");
  } else if (event.type === "steering_queued") {
    tui.setQueued(event.queueSize);
  } else if (event.type === "steering_applied") {
    tui.setQueued(event.queueSize);
    tui.setStatus("Steering applied.");
  } else if (event.type === "model_retry") {
    tui.setStatus(
      `Provider retry ${event.attempt} in ${event.delayMs}ms${event.status ? ` · HTTP ${event.status}` : ""}`,
    );
  } else if (event.type === "compaction") {
    tui.addMessage("system", "Context compacted: " + event.droppedMessages + " messages.");
  } else if (event.type === "error") {
    tui.addMessage("system", event.message);
    tui.setMood("oops");
  } else if (event.type === "agent_end") {
    tui.setStatus(
      event.response.stopped +
        " · " +
        event.response.rounds +
        " round(s) · " +
        event.response.toolCalls +
        " tool call(s)",
    );
  }
}

async function loadTheme(value: string | TuiTheme, cwd: string): Promise<TuiTheme> {
  if (typeof value !== "string") return validateTuiTheme(value);
  if (!looksLikeJsonPath(value)) return getTheme(value);
  return validateTuiTheme(await readJsonArtifact(resolve(cwd, value), "theme"));
}

async function loadMascot(value: string | TuiMascot, cwd: string): Promise<TuiMascot> {
  if (typeof value !== "string") return validateTuiMascot(value);
  if (!looksLikeJsonPath(value)) return getMascot(value);
  return validateTuiMascot(await readJsonArtifact(resolve(cwd, value), "mascot"));
}

async function readJsonArtifact(path: string, label: string): Promise<unknown> {
  const source = await readFile(path, "utf8");
  if (Buffer.byteLength(source) > 64_000) throw new Error(`Custom ${label} exceeds 64 KB`);
  try {
    return JSON.parse(source) as unknown;
  } catch (error) {
    throw new Error(
      `Invalid custom ${label} JSON: ${error instanceof Error ? error.message : String(error)}`,
    );
  }
}

function looksLikeJsonPath(value: string): boolean {
  return value.endsWith(".json") || value.includes("/") || value.includes("\\");
}

async function loadKeymap(
  path?: string,
  configured: Record<string, string> = {},
): Promise<TuiKeymap> {
  const value = path
    ? (JSON.parse(await readFile(resolve(path), "utf8")) as Record<string, string>)
    : {};
  return mergeKeymap({ ...configured, ...value } as Partial<TuiKeymap>);
}

function tuiHelp(): string {
  return [
    "/help · /status · /tools · /compact",
    "/image <path-or-url> · /images · /image clear",
    "/interrupt <instruction> · /followup <instruction> · busy input queues steering",
    "/model [provider/model] · /approval <mode>",
    "/sessions · /resume <id> · /new · /fork · /tree",
    "/skills · /skill <name> · /reload · /export",
    "/exit",
    "Ctrl+O newline · Ctrl+C abort · Ctrl+D exit · Ctrl+G mascot · Ctrl+T theme",
  ].join("\n");
}

function isApprovalMode(value: string): value is ApprovalMode {
  return ["ask", "auto-edit", "full-auto", "deny"].includes(value);
}
