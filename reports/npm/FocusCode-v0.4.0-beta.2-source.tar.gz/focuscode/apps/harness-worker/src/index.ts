#!/usr/bin/env node
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { TaskSpecSchema, assertSchema, type TaskSpecV1 } from "@focuscode/contracts";
import { createLocalHarness, type ApprovalMode, type ScriptedStep } from "@focuscode/sdk";

interface WorkerJob {
  schemaVersion: "worker-job.v1";
  repoRoot: string;
  stateDirectory: string;
  taskId: string;
  task: TaskSpecV1;
  approvalMode: ApprovalMode;
  trustRepoConfig?: boolean;
  model:
    | { kind: "scripted"; steps: ScriptedStep[] }
    | { kind: "openai-compatible"; modelId: string; baseUrl: string; apiKey?: string };
}

async function main(): Promise<void> {
  const jobPath = process.argv[2];
  if (!jobPath) throw new Error("Usage: harness-worker <worker-job.json>");
  const value: unknown = JSON.parse(await readFile(resolve(jobPath), "utf8"));
  if (!value || typeof value !== "object") throw new Error("Worker job must be an object");
  const job = value as WorkerJob;
  if (job.schemaVersion !== "worker-job.v1") throw new Error("Unsupported worker job version");
  assertSchema(TaskSpecSchema, job.task, "worker task");
  const common = {
    repoRoot: resolve(job.repoRoot),
    stateDirectory: resolve(job.stateDirectory),
    approvalMode: job.approvalMode,
    trustRepoConfig: job.trustRepoConfig ?? false,
  };
  const harness =
    job.model.kind === "scripted"
      ? await createLocalHarness({ ...common, model: job.model })
      : await createLocalHarness({
          ...common,
          model: {
            kind: "openai-compatible",
            modelId: job.model.modelId,
            baseUrl: job.model.baseUrl,
            ...(job.model.apiKey ? { apiKey: job.model.apiKey } : {}),
          },
        });
  const result = await harness.run(job.task, { taskId: job.taskId });
  process.stdout.write(
    `${JSON.stringify(
      {
        taskId: result.checkpoint.taskId,
        state: result.checkpoint.state,
        eventVersion: result.checkpoint.eventVersion,
        verification: result.verification?.conclusion,
      },
      null,
      2,
    )}\n`,
  );
  process.exitCode = result.checkpoint.state === "REVIEW_READY" ? 0 : 2;
}

main().catch((error) => {
  process.stderr.write(
    `harness-worker: ${error instanceof Error ? error.message : String(error)}\n`,
  );
  process.exitCode = 1;
});
