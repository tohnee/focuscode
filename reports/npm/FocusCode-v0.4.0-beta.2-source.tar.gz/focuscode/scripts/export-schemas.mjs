import { mkdir, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import {
  ActionIntentSchema,
  CapabilityGrantSchema,
  DomainEventSchema,
  EffectReceiptSchema,
  ExecutionContextSchema,
  KernelCheckpointSchema,
  MemoryRecordSchema,
  ModelDecisionSchema,
  TaskSpecSchema,
  TurnInputSchema,
  VerificationReportSchema,
} from "../packages/contracts/dist/index.js";

const directory = resolve("docs", "schemas");
await mkdir(directory, { recursive: true });
const schemas = new Map([
  ["task-spec.v1", TaskSpecSchema],
  ["execution-context.v1", ExecutionContextSchema],
  ["model-decision.v1", ModelDecisionSchema],
  ["action-intent.v1", ActionIntentSchema],
  ["capability-grant.v1", CapabilityGrantSchema],
  ["effect-receipt.v1", EffectReceiptSchema],
  ["domain-event.v1", DomainEventSchema],
  ["kernel-checkpoint.v1", KernelCheckpointSchema],
  ["memory-record.v1", MemoryRecordSchema],
  ["turn-input.v1", TurnInputSchema],
  ["verification-report.v1", VerificationReportSchema],
]);

for (const [id, schema] of schemas) {
  const document = { $schema: "http://json-schema.org/draft-07/schema#", $id: id, ...schema };
  await writeFile(
    resolve(directory, `${id}.schema.json`),
    `${JSON.stringify(document, null, 2)}\n`,
  );
}
process.stdout.write(`Exported ${schemas.size} canonical schemas to ${directory}\n`);
