import { mkdir, readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { createTestDirectory, type ScriptedStep } from "@focuscode/testkit";
import { createCodingAgent, createLocalHarness } from "../src/index.js";

describe("LocalHarness end-to-end", () => {
  it("constructs the conversational coding-agent SDK without global state", async () => {
    const repoRoot = await createTestDirectory("sdk-agent");
    const created = await createCodingAgent({
      cwd: repoRoot,
      provider: "custom",
      model: "fixture",
      baseUrl: "http://127.0.0.1:1/v1",
      approval: "deny",
      sandbox: { kind: "host" },
      persistentSession: false,
      projectTrusted: false,
    });
    expect(await created.agent.status()).toMatchObject({
      provider: "custom",
      model: "fixture",
      approval: "deny",
    });
    expect(created.extensions.list()).toEqual([]);
  });

  it("repairs a repository through the canonical decision/effect/verification loop", async () => {
    const repoRoot = await createTestDirectory("sdk-repo");
    const stateDirectory = await createTestDirectory("sdk-state");
    await mkdir(join(repoRoot, "src"));
    await mkdir(join(repoRoot, "test"));
    await mkdir(join(repoRoot, ".focuscode"));
    await writeFile(join(repoRoot, "package.json"), '{"name":"e2e","type":"module"}\n');
    await writeFile(
      join(repoRoot, "src", "math.js"),
      "export function add(a, b) { return a - b; }\n",
    );
    await writeFile(
      join(repoRoot, "test", "math.test.js"),
      [
        'import test from "node:test";',
        'import assert from "node:assert/strict";',
        'import { add } from "../src/math.js";',
        'test("add", () => assert.equal(add(2, 3), 5));',
        "",
      ].join("\n"),
    );
    await writeFile(
      join(repoRoot, ".focuscode", "config.json"),
      JSON.stringify({
        schemaVersion: "focuscode-repo.v1",
        protectedPaths: [".git", ".focuscode"],
        commands: [{ id: "test", argv: [process.execPath, "--test"], timeoutMs: 30_000 }],
        verificationCommandIds: ["test"],
      }),
    );
    const steps: ScriptedStep[] = [
      {
        kind: "tool_intent_template",
        intents: [
          {
            toolId: "apply_edit_ir",
            arguments: {
              path: "src/math.js",
              edits: [{ search: "a - b", replace: "a + b", expectedOccurrences: 1 }],
            },
            expectedEffects: [
              { class: "file_write", resource: "src/math.js", description: "Fix operator" },
            ],
            justification: "Unique one-line repair",
          },
        ],
      },
      { kind: "completion_candidate", summary: "fixed", evidence: [], residualRisks: [] },
    ];
    const harness = await createLocalHarness({
      repoRoot,
      stateDirectory,
      approvalMode: "auto-safe",
      trustRepoConfig: true,
      model: { kind: "scripted", steps },
    });
    const result = await harness.run(
      {
        schemaVersion: "task-spec.v1",
        repoId: repoRoot,
        baseRef: "WORKTREE",
        mode: "change",
        objective: "Fix add",
        acceptanceCriteria: [{ id: "test", description: "Tests pass" }],
      },
      { taskId: "sdk-e2e" },
    );
    expect(result.checkpoint.state).toBe("REVIEW_READY");
    expect(result.verification?.conclusion).toBe("PASS");
    expect(await readFile(join(repoRoot, "src", "math.js"), "utf8")).toContain("a + b");
    expect(harness.actions.ledgerSnapshot().changedFiles).toEqual(["src/math.js"]);
    expect((await harness.facts.loadEvents("sdk-e2e")).map((event) => event.kind)).toContain(
      "EffectObserved",
    );
  });
});
