import { describe, expect, it } from "vitest";
import { EventEmitter } from "node:events";
import type { ReadStream, WriteStream } from "node:tty";
import {
  DEFAULT_KEYMAP,
  FullScreenTui,
  TUI_MASCOTS,
  TUI_THEMES,
  TerminalInputDecoder,
  getMascot,
  getTheme,
  mascotFrame,
  mergeKeymap,
  parseTerminalInput,
  renderTui,
  validateTuiMascot,
  validateTuiTheme,
} from "../src/index.js";

describe("TUI primitives", () => {
  it("parses printable, navigation and configurable control keys", () => {
    expect(parseTerminalInput("hi\u001b[A\r\u0003")).toEqual([
      { type: "text", text: "h" },
      { type: "text", text: "i" },
      { type: "action", action: "history_previous" },
      { type: "action", action: "submit" },
      { type: "action", action: "abort" },
    ]);
    expect(parseTerminalInput("\u001b[200~line one\nline two\u001b[201~")).toEqual([
      { type: "text", text: "line one\nline two" },
    ]);
    const decoder = new TerminalInputDecoder();
    expect(decoder.push("\u001b[20")).toEqual([]);
    expect(decoder.push("0~pasted\ntext\u001b[20")).toEqual([]);
    expect(decoder.push("1~")).toEqual([{ type: "text", text: "pasted\ntext" }]);
    const custom = mergeKeymap({ "ctrl+x": "abort" });
    expect(custom["ctrl+x"]).toBe("abort");
    expect(custom["ctrl+c"]).toBeUndefined();
    expect(() => mergeKeymap({ bad: "abort" })).toThrow("Invalid key");
  });

  it("ships multiple animated cute mascots and themes", () => {
    expect(TUI_MASCOTS.length).toBeGreaterThanOrEqual(6);
    expect(TUI_THEMES.length).toBeGreaterThanOrEqual(5);
    expect(mascotFrame(getMascot("mochi"), "idle", 0).join("\n")).toContain("ᐠ");
    expect(mascotFrame(getMascot("mochi"), "idle", 1)).not.toEqual(
      mascotFrame(getMascot("mochi"), "idle", 0),
    );
    expect(() => getTheme("missing")).toThrow("Unknown");
    const customTheme = validateTuiTheme({
      ...getTheme("aurora"),
      id: "team-blue",
      name: "Team Blue",
      accent: 45,
    });
    expect(getTheme(customTheme).id).toBe("team-blue");
    const customMascot = validateTuiMascot({
      ...getMascot("mochi"),
      id: "team-pet",
      name: "Team Pet",
    });
    expect(getMascot(customMascot).name).toBe("Team Pet");
    expect(() => validateTuiTheme({ ...customTheme, accent: 999 })).toThrow("ANSI color");
    expect(() => validateTuiMascot({ ...customMascot, name: "bad\u001b[2J" })).toThrow("name");
  });

  it("renders a bounded full-screen frame with status, transcript and queue", () => {
    const output = renderTui({
      width: 80,
      height: 24,
      title: "FocusCode",
      model: "openai/gpt",
      session: "session_1",
      approval: "ask",
      sandbox: "gvisor",
      busy: true,
      queued: 2,
      mood: "working",
      tick: 0,
      theme: getTheme("aurora"),
      mascot: getMascot("byte"),
      transcript: [
        { role: "user", text: "fix tests" },
        { role: "assistant", text: "Inspecting \u001b[2Jfiles" },
      ],
      input: "also\nupdate docs",
      cursor: 4,
      attachments: ["screen.png"],
      scrollOffset: 0,
    });
    expect(output).toContain("FocusCode");
    expect(output).toContain("queued 2");
    expect(output).toContain("screen.png");
    expect(output).not.toContain("\u001b[2J");
    expect(output).toContain("↵");
    expect(output.split("\n")).toHaveLength(24);
    expect(DEFAULT_KEYMAP.enter).toBe("submit");
  });

  it("runs raw full-screen input, approvals, steering and restores the terminal", async () => {
    const input = new FakeInput();
    const output = new FakeOutput();
    const submitted: string[] = [];
    const steered: string[] = [];
    let release!: () => void;
    const blocked = new Promise<void>((resolve) => {
      release = resolve;
    });
    const tui = new FullScreenTui({
      input: input as unknown as ReadStream,
      output: output as unknown as WriteStream,
      model: "fixture/model",
      session: "session_1",
      approval: "ask",
      sandbox: "docker",
      onSubmit: async (text) => {
        submitted.push(text);
        await blocked;
      },
      onSteer: async (text) => {
        steered.push(text);
      },
      onAbort: () => undefined,
    });
    const running = tui.run();
    input.emit("data", "first\r");
    await tick();
    input.emit("data", "second\r");
    await tick();
    expect(submitted).toEqual(["first"]);
    expect(steered).toEqual(["second"]);
    tui.setModel("next/model");
    tui.setSession("session_2");
    tui.setApproval("deny");
    expect(tui.snapshot()).toMatchObject({
      model: "next/model",
      session: "session_2",
      approval: "deny",
    });
    release();
    await tick();
    const approval = tui.requestApproval("Allow write?");
    input.emit("data", "y\r");
    await expect(approval).resolves.toBe(true);
    input.emit("data", "\u0004");
    await running;
    expect(input.rawModes).toEqual([true, false]);
    expect(output.content).toContain("\u001b[?1049h");
    expect(output.content).toContain("\u001b[?1049l");
  });
});

class FakeInput extends EventEmitter {
  isTTY = true;
  rawModes: boolean[] = [];

  setRawMode(value: boolean): this {
    this.rawModes.push(value);
    return this;
  }

  setEncoding(): this {
    return this;
  }

  resume(): this {
    return this;
  }
}

class FakeOutput extends EventEmitter {
  isTTY = true;
  columns = 80;
  rows = 24;
  content = "";

  write(value: string): boolean {
    this.content += value;
    return true;
  }
}

async function tick(): Promise<void> {
  await new Promise((resolve) => setTimeout(resolve, 0));
}
