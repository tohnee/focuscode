import type { ReadStream, WriteStream } from "node:tty";
import { DEFAULT_KEYMAP, TerminalInputDecoder, type TuiAction, type TuiKeymap } from "./keymap.js";
import { getMascot, TUI_MASCOTS, type MascotMood, type TuiMascot } from "./mascots.js";
import { renderTui, type TuiRenderState, type TuiTranscriptLine } from "./renderer.js";
import { getTheme, TUI_THEMES, type TuiTheme } from "./themes.js";

export interface FullScreenTuiOptions {
  input: ReadStream;
  output: WriteStream;
  title?: string;
  model: string;
  session: string;
  approval: string;
  sandbox: string;
  theme?: string | TuiTheme;
  mascot?: string | TuiMascot;
  keymap?: TuiKeymap;
  onSubmit(text: string): Promise<void>;
  onSteer(text: string): Promise<void>;
  onAbort(): void;
  onCommand?(command: string): Promise<string | void>;
}

export class FullScreenTui {
  private theme: TuiTheme;
  private mascot: TuiMascot;
  private model: string;
  private session: string;
  private approval: string;
  private readonly keymap: TuiKeymap;
  private transcript: TuiTranscriptLine[] = [];
  private inputBuffer = "";
  private cursor = 0;
  private history: string[] = [];
  private historyIndex = 0;
  private busy = false;
  private queued = 0;
  private mood: MascotMood = "idle";
  private tick = 0;
  private attachments: string[] = [];
  private status: string | undefined;
  private scrollOffset = 0;
  private disposed = false;
  private exitResolve!: () => void;
  private readonly exited = new Promise<void>((resolve) => {
    this.exitResolve = resolve;
  });
  private timer?: NodeJS.Timeout;
  private approvalResolve: ((allowed: boolean) => void) | undefined;
  private readonly inputDecoder: TerminalInputDecoder;
  private lastFrame: string[] = [];
  private lastDimensions = "";

  constructor(private readonly options: FullScreenTuiOptions) {
    this.theme = getTheme(options.theme);
    this.mascot = getMascot(options.mascot);
    this.model = options.model;
    this.session = options.session;
    this.approval = options.approval;
    this.keymap = options.keymap ?? DEFAULT_KEYMAP;
    this.inputDecoder = new TerminalInputDecoder(this.keymap);
  }

  async run(): Promise<void> {
    if (!this.options.input.isTTY || !this.options.output.isTTY) {
      throw new Error("Full-screen TUI requires a TTY");
    }
    this.options.input.setRawMode(true);
    this.options.input.setEncoding("utf8");
    this.options.input.resume();
    this.options.output.write("\u001b[?1049h\u001b[?25l\u001b[?2004h");
    this.options.input.on("data", this.onData);
    this.options.output.on("resize", this.onResize);
    this.timer = setInterval(() => {
      this.tick += 1;
      this.render();
    }, 500);
    this.timer.unref();
    this.render();
    await this.exited;
  }

  addMessage(role: TuiTranscriptLine["role"], text: string): void {
    this.transcript.push({ role, text });
    this.transcript = this.transcript.slice(-500);
    this.scrollOffset = 0;
    this.render();
  }

  appendAssistant(delta: string): void {
    const last = this.transcript.at(-1);
    if (last?.role === "assistant") last.text += delta;
    else this.transcript.push({ role: "assistant", text: delta });
    this.render();
  }

  setBusy(busy: boolean): void {
    this.busy = busy;
    this.mood = busy ? "thinking" : "idle";
    this.render();
  }

  setQueued(count: number): void {
    this.queued = Math.max(0, count);
    this.render();
  }

  setMood(mood: MascotMood): void {
    this.mood = mood;
    this.render();
  }

  setStatus(status?: string): void {
    this.status = status;
    this.render();
  }

  setAttachments(names: string[]): void {
    this.attachments = [...names];
    this.render();
  }

  setModel(model: string): void {
    this.model = model;
    this.render();
  }

  setSession(session: string): void {
    this.session = session;
    this.render();
  }

  setApproval(approval: string): void {
    this.approval = approval;
    this.render();
  }

  requestApproval(question: string): Promise<boolean> {
    if (this.approvalResolve) throw new Error("Another approval is already pending");
    this.status = question + " Type y or n, then Enter.";
    this.render();
    return new Promise<boolean>((resolve) => {
      this.approvalResolve = resolve;
    });
  }

  async submitText(text: string): Promise<void> {
    const prompt = text.trim();
    if (!prompt) return;
    this.history.push(prompt);
    this.historyIndex = this.history.length;
    if (prompt.startsWith("/") && this.options.onCommand) {
      const result = await this.options.onCommand(prompt);
      if (result) this.addMessage("system", result);
      return;
    }
    if (this.busy) {
      this.addMessage("user", "[steer] " + prompt);
      await this.options.onSteer(prompt);
      return;
    }
    this.addMessage("user", prompt);
    this.setBusy(true);
    try {
      await this.options.onSubmit(prompt);
      this.setMood("happy");
    } catch (error) {
      this.setMood("oops");
      throw error;
    } finally {
      this.setBusy(false);
    }
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    if (this.timer) clearInterval(this.timer);
    this.options.input.off("data", this.onData);
    this.options.output.off("resize", this.onResize);
    this.approvalResolve?.(false);
    this.approvalResolve = undefined;
    this.inputDecoder.reset();
    this.options.input.setRawMode(false);
    this.options.output.write("\u001b[?2004l\u001b[?25h\u001b[?1049l");
    this.exitResolve();
  }

  snapshot(): TuiRenderState {
    return {
      width: this.options.output.columns || 80,
      height: this.options.output.rows || 24,
      title: this.options.title ?? "FocusCode",
      model: this.model,
      session: this.session,
      approval: this.approval,
      sandbox: this.options.sandbox,
      busy: this.busy,
      queued: this.queued,
      mood: this.mood,
      tick: this.tick,
      theme: this.theme,
      mascot: this.mascot,
      transcript: this.transcript.map((line) => ({ ...line })),
      input: this.inputBuffer,
      cursor: this.cursor,
      attachments: [...this.attachments],
      ...(this.status ? { status: this.status } : {}),
      scrollOffset: this.scrollOffset,
    };
  }

  private readonly onResize = () => this.render();

  private readonly onData = (data: Buffer | string) => {
    const value = Buffer.isBuffer(data) ? data.toString("utf8") : data;
    for (const key of this.inputDecoder.push(value)) {
      if (key.type === "text") {
        this.inputBuffer =
          this.inputBuffer.slice(0, this.cursor) + key.text + this.inputBuffer.slice(this.cursor);
        this.cursor += key.text.length;
      } else {
        void this.action(key.action).catch((error: unknown) => {
          this.setStatus(error instanceof Error ? error.message : String(error));
          this.setMood("oops");
        });
      }
    }
    this.render();
  };

  private async action(action: TuiAction): Promise<void> {
    if (action === "exit") {
      if (this.busy) this.options.onAbort();
      else this.dispose();
      return;
    }
    if (action === "abort") {
      if (this.busy) this.options.onAbort();
      else this.setStatus("No active turn. Ctrl+D exits.");
      return;
    }
    if (action === "submit") {
      const text = this.inputBuffer.trim();
      if (!text) return;
      this.inputBuffer = "";
      this.cursor = 0;
      if (this.approvalResolve) {
        const resolveApproval = this.approvalResolve;
        this.approvalResolve = undefined;
        const allowed = ["y", "yes"].includes(text.toLowerCase());
        this.status = allowed ? "Approved once." : "Denied.";
        resolveApproval(allowed);
        this.render();
        return;
      }
      await this.submitText(text);
      return;
    }
    if (action === "newline") {
      this.inputBuffer =
        this.inputBuffer.slice(0, this.cursor) + "\n" + this.inputBuffer.slice(this.cursor);
      this.cursor += 1;
    } else if (action === "backspace" && this.cursor > 0) {
      this.inputBuffer =
        this.inputBuffer.slice(0, this.cursor - 1) + this.inputBuffer.slice(this.cursor);
      this.cursor -= 1;
    } else if (action === "delete_word" && this.cursor > 0) {
      const before = this.inputBuffer.slice(0, this.cursor).replace(/\s*\S+\s*$/, "");
      this.inputBuffer = before + this.inputBuffer.slice(this.cursor);
      this.cursor = before.length;
    } else if (action === "cursor_left") {
      this.cursor = Math.max(0, this.cursor - 1);
    } else if (action === "cursor_right") {
      this.cursor = Math.min(this.inputBuffer.length, this.cursor + 1);
    } else if (action === "history_previous") {
      this.recall(-1);
    } else if (action === "history_next") {
      this.recall(1);
    } else if (action === "scroll_up") {
      this.scrollOffset += 5;
    } else if (action === "scroll_down") {
      this.scrollOffset = Math.max(0, this.scrollOffset - 5);
    } else if (action === "clear") {
      this.transcript = [];
    } else if (action === "cycle_theme") {
      this.theme = TUI_THEMES[(TUI_THEMES.indexOf(this.theme) + 1) % TUI_THEMES.length]!;
      this.setStatus("Theme: " + this.theme.name);
    } else if (action === "cycle_mascot") {
      this.mascot = TUI_MASCOTS[(TUI_MASCOTS.indexOf(this.mascot) + 1) % TUI_MASCOTS.length]!;
      this.setStatus(
        this.mascot.name + " · " + this.mascot.species + " · " + this.mascot.catchphrase,
      );
    }
  }

  private recall(delta: number): void {
    if (!this.history.length) return;
    this.historyIndex = Math.max(0, Math.min(this.history.length, this.historyIndex + delta));
    this.inputBuffer = this.history[this.historyIndex] ?? "";
    this.cursor = this.inputBuffer.length;
  }

  private render(): void {
    if (this.disposed) return;
    const snapshot = this.snapshot();
    const frame = renderTui(snapshot).split("\n");
    const dimensions = `${snapshot.width}x${snapshot.height}`;
    if (this.lastFrame.length === 0 || dimensions !== this.lastDimensions) {
      this.options.output.write("\u001b[H" + frame.join("\n") + "\u001b[J");
    } else {
      let patch = "";
      const rows = Math.max(frame.length, this.lastFrame.length);
      for (let row = 0; row < rows; row += 1) {
        if (frame[row] === this.lastFrame[row]) continue;
        patch += `\u001b[${row + 1};1H\u001b[2K${frame[row] ?? ""}`;
      }
      if (patch) this.options.output.write(patch);
    }
    this.lastFrame = frame;
    this.lastDimensions = dimensions;
  }
}
