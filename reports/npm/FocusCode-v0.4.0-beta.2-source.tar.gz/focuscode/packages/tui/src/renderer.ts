import { mascotFrame, type MascotMood, type TuiMascot } from "./mascots.js";
import { bg, fg, type TuiTheme } from "./themes.js";

export interface TuiTranscriptLine {
  role: "user" | "assistant" | "tool" | "system";
  text: string;
}

export interface TuiRenderState {
  width: number;
  height: number;
  title: string;
  model: string;
  session: string;
  approval: string;
  sandbox: string;
  busy: boolean;
  queued: number;
  mood: MascotMood;
  tick: number;
  theme: TuiTheme;
  mascot: TuiMascot;
  transcript: TuiTranscriptLine[];
  input: string;
  cursor: number;
  attachments: string[];
  status?: string;
  scrollOffset: number;
}

export function renderTui(state: TuiRenderState): string {
  const width = Math.max(40, state.width);
  const height = Math.max(12, state.height);
  const theme = state.theme;
  const top = fg(theme.accent, "╭" + "─".repeat(width - 2) + "╮");
  const bottom = fg(theme.accent, "╰" + "─".repeat(width - 2) + "╯");
  const headerText =
    " " + sanitizeTerminalText(state.title) + " · " + sanitizeTerminalText(state.model) + " ";
  const header =
    fg(theme.accent, "│") +
    bold(fg(theme.foreground, padVisible(headerText, width - 2))) +
    fg(theme.accent, "│");
  const mascot = mascotFrame(state.mascot, state.mood, state.tick);
  const mascotWidth = Math.min(22, Math.max(...mascot.map(visibleLength), 0) + 2);
  const bodyWidth = width - mascotWidth - 3;
  const bodyHeight = Math.max(6, height - 6);
  const lines = wrapTranscript(state.transcript, bodyWidth);
  const end = Math.max(0, lines.length - state.scrollOffset);
  const visible = lines.slice(Math.max(0, end - bodyHeight), end);
  const body: string[] = [];
  for (let row = 0; row < bodyHeight; row += 1) {
    const mascotText = mascot[row] ?? "";
    const transcript = visible[row] ?? "";
    body.push(
      fg(theme.accent, "│") +
        fg(theme.secondary, padVisible(" " + mascotText, mascotWidth)) +
        fg(theme.muted, "│") +
        padVisible(" " + transcript, bodyWidth + 1) +
        fg(theme.accent, "│"),
    );
  }
  const separator = fg(theme.muted, "├" + "─".repeat(width - 2) + "┤");
  const attachmentText = state.attachments.length
    ? " 📎 " + state.attachments.map(sanitizeTerminalText).join(", ")
    : "";
  const prompt =
    (state.busy ? "steer»" : "focus»") +
    " " +
    renderInputCursor(state.input, state.cursor) +
    attachmentText;
  const inputLine =
    fg(theme.accent, "│") +
    fg(theme.foreground, padVisible(prompt, width - 2)) +
    fg(theme.accent, "│");
  const queue = state.queued ? " · queued " + state.queued : "";
  const footerText =
    " " +
    sanitizeTerminalText(state.mascot.name) +
    " · " +
    state.approval +
    " · " +
    state.sandbox +
    queue +
    " · Ctrl+O newline · Ctrl+G mascot · Ctrl+T theme ";
  const footer =
    fg(theme.accent, "│") +
    fg(
      theme.muted,
      padVisible(
        state.status
          ? " " + sanitizeTerminalText(state.status).replaceAll(/\r?\n/g, " ") + " "
          : footerText,
        width - 2,
      ),
    ) +
    fg(theme.accent, "│");
  return bg(
    theme.background,
    [top, header, ...body, separator, inputLine, footer, bottom].join("\n"),
  );
}

function renderInputCursor(input: string, cursor: number): string {
  const display = input.replaceAll("\n", "↵");
  const position = Math.max(0, Math.min(display.length, cursor));
  const current = display[position] ?? " ";
  return (
    display.slice(0, position) +
    "\u001b[7m" +
    current +
    "\u001b[27m" +
    display.slice(position + (position < display.length ? 1 : 0))
  );
}

function wrapTranscript(transcript: TuiTranscriptLine[], width: number): string[] {
  const colors: Record<TuiTranscriptLine["role"], number> = {
    user: 81,
    assistant: 255,
    tool: 221,
    system: 245,
  };
  const result: string[] = [];
  for (const line of transcript) {
    const prefix = line.role + "> ";
    for (const [index, segment] of wrap(
      line.text || " ",
      Math.max(10, width - prefix.length),
    ).entries()) {
      result.push(
        fg(colors[line.role], (index === 0 ? prefix : " ".repeat(prefix.length)) + segment),
      );
    }
  }
  return result;
}

function wrap(text: string, width: number): string[] {
  const lines: string[] = [];
  for (const logical of sanitizeTerminalText(text).replaceAll("\t", "  ").split("\n")) {
    if (!logical) {
      lines.push("");
      continue;
    }
    let remaining = logical;
    while (visibleLength(remaining) > width) {
      lines.push(remaining.slice(0, width));
      remaining = remaining.slice(width);
    }
    lines.push(remaining);
  }
  return lines;
}

function sanitizeTerminalText(value: string): string {
  return value
    .replace(/\u001b(?:\[[0-?]*[ -/]*[@-~]|\][^\u0007]*(?:\u0007|\u001b\\)?)/g, "")
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f]/g, "");
}

function padVisible(value: string, width: number): string {
  const clean = truncateVisible(value, width);
  return clean + " ".repeat(Math.max(0, width - visibleLength(clean)));
}

function truncateVisible(value: string, width: number): string {
  if (visibleLength(value) <= width) return value;
  const plain = stripAnsi(value);
  return plain.slice(0, Math.max(0, width - 1)) + "…";
}

function visibleLength(value: string): number {
  return [...stripAnsi(value)].length;
}

function stripAnsi(value: string): string {
  return value.replace(/\u001b\[[0-9;]*m/g, "");
}

function bold(value: string): string {
  return "\u001b[1m" + value + "\u001b[22m";
}
