export type TuiAction =
  | "submit"
  | "newline"
  | "abort"
  | "exit"
  | "clear"
  | "backspace"
  | "delete_word"
  | "cursor_left"
  | "cursor_right"
  | "history_previous"
  | "history_next"
  | "scroll_up"
  | "scroll_down"
  | "cycle_theme"
  | "cycle_mascot";

export type TuiKeymap = Record<string, TuiAction>;

export const DEFAULT_KEYMAP: TuiKeymap = {
  enter: "submit",
  "ctrl+o": "newline",
  "ctrl+c": "abort",
  "ctrl+d": "exit",
  "ctrl+l": "clear",
  backspace: "backspace",
  "ctrl+w": "delete_word",
  left: "cursor_left",
  right: "cursor_right",
  up: "history_previous",
  down: "history_next",
  pageup: "scroll_up",
  pagedown: "scroll_down",
  "ctrl+t": "cycle_theme",
  "ctrl+g": "cycle_mascot",
};

export type ParsedKey = { type: "action"; action: TuiAction } | { type: "text"; text: string };

export function parseTerminalInput(input: string, keymap: TuiKeymap = DEFAULT_KEYMAP): ParsedKey[] {
  return parseBufferedInput(input, keymap).parsed;
}

export class TerminalInputDecoder {
  private buffer = "";

  constructor(private readonly keymap: TuiKeymap = DEFAULT_KEYMAP) {}

  push(input: string): ParsedKey[] {
    this.buffer += input;
    const result = parseBufferedInput(this.buffer, this.keymap);
    this.buffer = this.buffer.slice(result.consumed);
    return result.parsed;
  }

  reset(): void {
    this.buffer = "";
  }
}

const TERMINAL_SEQUENCES: Array<[string, string]> = [
  ["\u001b[5~", "pageup"],
  ["\u001b[6~", "pagedown"],
  ["\u001b[A", "up"],
  ["\u001b[B", "down"],
  ["\u001b[C", "right"],
  ["\u001b[D", "left"],
  ["\r", "enter"],
  ["\n", "enter"],
  ["\u007f", "backspace"],
  ["\b", "backspace"],
];

function parseBufferedInput(
  input: string,
  keymap: TuiKeymap,
): { parsed: ParsedKey[]; consumed: number } {
  const parsed: ParsedKey[] = [];
  let index = 0;
  while (index < input.length) {
    if (input.startsWith("\u001b[200~", index)) {
      const end = input.indexOf("\u001b[201~", index + 6);
      if (end < 0) break;
      const pasted = input.slice(index + 6, end);
      if (pasted) parsed.push({ type: "text", text: pasted });
      index = end + 6;
      continue;
    }
    const matched = terminalKeyAt(input, index);
    if (matched) {
      const action = keymap[matched.key];
      if (action) parsed.push({ type: "action", action });
      index += matched.length;
      continue;
    }
    const rest = input.slice(index);
    if (
      ["\u001b[200~", ...TERMINAL_SEQUENCES.map(([sequence]) => sequence)].some(
        (sequence) => sequence.startsWith(rest) && sequence !== rest,
      )
    ) {
      break;
    }
    const point = input.codePointAt(index);
    if (point === undefined) break;
    const text = String.fromCodePoint(point);
    if ((point >= 32 && point !== 127) || text === "\t") parsed.push({ type: "text", text });
    index += text.length;
  }
  return { parsed, consumed: index };
}

export function mergeKeymap(overrides: Partial<TuiKeymap> = {}): TuiKeymap {
  const result = { ...DEFAULT_KEYMAP };
  for (const [key, action] of Object.entries(overrides)) {
    if (!action) continue;
    if (!validKey(key)) throw new Error("Invalid key binding: " + key);
    if (!Object.values(DEFAULT_KEYMAP).includes(action))
      throw new Error("Invalid TUI action: " + action);
    for (const [existing, value] of Object.entries(result)) {
      if (value === action) delete result[existing];
    }
    result[key] = action;
  }
  return result;
}

function terminalKeyAt(value: string, index: number): { key: string; length: number } | undefined {
  const rest = value.slice(index);
  for (const [sequence, key] of TERMINAL_SEQUENCES) {
    if (rest.startsWith(sequence)) return { key, length: sequence.length };
  }
  const code = value.charCodeAt(index);
  if (code >= 1 && code <= 26) {
    return { key: "ctrl+" + String.fromCharCode(96 + code), length: 1 };
  }
  return undefined;
}

function validKey(value: string): boolean {
  return /^(ctrl\+[a-z]|enter|backspace|left|right|up|down|pageup|pagedown)$/.test(value);
}
