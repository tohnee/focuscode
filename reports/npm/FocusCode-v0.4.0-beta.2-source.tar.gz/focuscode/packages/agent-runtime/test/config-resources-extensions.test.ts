import { mkdir, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { createTestDirectory } from "@focuscode/testkit";
import {
  AgentToolRegistry,
  ExtensionHost,
  expandFileMentions,
  expandPromptTemplate,
  listProviderPresets,
  loadAgentResources,
  renderResourcePrompt,
  resolveAgentConfig,
} from "../src/index.js";

describe("configuration and resources", () => {
  it("merges trusted project configuration over global defaults", async () => {
    const root = await createTestDirectory("agent-config");
    const global = join(root, "global.json");
    const project = join(root, ".focuscode", "agent.json");
    await mkdir(join(root, ".focuscode"));
    await writeFile(
      global,
      JSON.stringify({
        schemaVersion: "focuscode-agent.v1",
        provider: "ollama",
        model: "global-model",
        approval: "deny",
        contextWindow: 8_000,
      }),
    );
    await writeFile(
      project,
      JSON.stringify({
        schemaVersion: "focuscode-agent.v1",
        model: "project-model",
        approval: "auto-edit",
        disabledTools: ["bash"],
      }),
    );
    const config = await resolveAgentConfig(root, {
      globalConfigPath: global,
      projectConfigPath: project,
      projectTrusted: true,
    });
    expect(config.model).toMatchObject({ provider: "ollama", model: "project-model" });
    expect(config.approval).toBe("auto-edit");
    expect(config.disabledTools).toEqual(["bash"]);
    expect(listProviderPresets().map((item) => item.id)).toContain("deepseek");
    expect(listProviderPresets().map((item) => item.id)).toEqual(
      expect.arrayContaining(["kimi", "qwen", "glm", "deepseek", "minimax"]),
    );

    const custom = await resolveAgentConfig(root, {
      provider: "private-local",
      model: "custom-model",
      globalConfigPath: join(root, "missing-global.json"),
      projectConfigPath: join(root, "missing-project.json"),
      providers: {
        "private-local": {
          protocol: "openai-chat",
          baseUrl: "http://127.0.0.1:9999/v1",
          defaultContextWindow: 32_000,
          defaultMaxOutputTokens: 2_000,
        },
      },
    });
    expect(custom.model).toMatchObject({
      provider: "private-local",
      baseUrl: "http://127.0.0.1:9999/v1",
      contextWindow: 32_000,
    });
    expect(custom.sandbox).toMatchObject({
      kind: "auto",
      network: "none",
      allowHostFallback: false,
    });
  });

  it("ships native profiles for the five requested open-model providers", async () => {
    const root = await createTestDirectory("agent-provider-profiles");
    const cases = [
      ["kimi", "kimi-k3", "openai", "openai-chat"],
      ["qwen", "qwen3-coder-plus", "qwen", "openai-chat"],
      ["glm", "glm-5.2", "zai", "openai-chat"],
      ["deepseek", "deepseek-v4-pro", "deepseek", "openai-chat"],
      ["minimax", "MiniMax-M3", "openai", "anthropic-messages"],
    ] as const;
    for (const [provider, model, thinkingFormat, protocol] of cases) {
      const config = await resolveAgentConfig(root, {
        provider,
        apiKey: "fixture-key",
        globalConfigPath: join(root, "missing.json"),
        projectConfigPath: join(root, "missing-project.json"),
      });
      expect(config.model).toMatchObject({ provider, model, protocol });
      expect(config.model.compatibility.thinkingFormat).toBe(thinkingFormat);
      expect(config.model.reliability.maxRetries).toBe(2);
    }
    const minimax = await resolveAgentConfig(root, {
      provider: "minimax",
      apiKey: "fixture-key",
      globalConfigPath: join(root, "missing.json"),
      projectConfigPath: join(root, "missing-project.json"),
    });
    expect(minimax.model.compatibility.anthropicThinking).toBe("adaptive");
    const vision = await resolveAgentConfig(root, {
      provider: "qwen",
      model: "qwen-vl-max",
      apiKey: "fixture-key",
      models: {
        "qwen/qwen-vl-max": {
          capabilities: { input: ["text", "image"], reasoning: true, toolCalling: true },
          maxOutputTokens: 32_000,
          reliability: { maxRetries: 4 },
        },
      },
      globalConfigPath: join(root, "missing.json"),
      projectConfigPath: join(root, "missing-project.json"),
    });
    expect(vision.model.capabilities.input).toContain("image");
    expect(vision.model.maxOutputTokens).toBe(32_000);
    expect(vision.model.reliability.maxRetries).toBe(4);
  });

  it("enforces enterprise provider, model, media, extension and sandbox boundaries", async () => {
    const root = await createTestDirectory("agent-enterprise-policy");
    const base = {
      provider: "deepseek",
      model: "deepseek-chat",
      apiKey: "fixture-key",
      globalConfigPath: join(root, "missing.json"),
      projectConfigPath: join(root, "missing-project.json"),
      enterprise: {
        enabled: true,
        allowedProviders: ["deepseek"],
        allowedModels: ["deepseek/deepseek-chat"],
      },
      sandbox: {
        kind: "docker" as const,
        image: "focuscode/sandbox@sha256:" + "a".repeat(64),
        allowHostFallback: false,
      },
    };
    const config = await resolveAgentConfig(root, base);
    expect(config.enterprise.enabled).toBe(true);
    expect(config.media.allowRemoteImages).toBe(false);
    await expect(resolveAgentConfig(root, { ...base, provider: "qwen" })).rejects.toThrow(
      "denies provider",
    );
    await expect(resolveAgentConfig(root, { ...base, sandbox: { kind: "host" } })).rejects.toThrow(
      "isolated sandbox",
    );
    await expect(
      resolveAgentConfig(root, { ...base, media: { allowRemoteImages: true } }),
    ).rejects.toThrow("remote image");
    await expect(
      resolveAgentConfig(root, { ...base, requireExtensionSignatures: false }),
    ).rejects.toThrow("signed extension");
  });

  it("rejects malformed provider, sandbox and keymap configuration", async () => {
    const root = await createTestDirectory("agent-invalid-config");
    const global = join(root, "global.json");
    await writeFile(
      global,
      JSON.stringify({
        schemaVersion: "focuscode-agent.v1",
        provider: "ollama",
        model: "fixture",
        protocol: "made-up",
      }),
    );
    await expect(
      resolveAgentConfig(root, {
        globalConfigPath: global,
        projectConfigPath: join(root, "missing.json"),
      }),
    ).rejects.toThrow("protocol must be one of");
    await writeFile(
      global,
      JSON.stringify({
        schemaVersion: "focuscode-agent.v1",
        provider: "ollama",
        model: "fixture",
        sandbox: { kind: "vm", vmHost: "agent@vm" },
      }),
    );
    await expect(
      resolveAgentConfig(root, {
        globalConfigPath: global,
        projectConfigPath: join(root, "missing.json"),
      }),
    ).rejects.toThrow("requires vmHost and vmWorkspace");
    await writeFile(
      global,
      JSON.stringify({
        schemaVersion: "focuscode-agent.v1",
        provider: "ollama",
        model: "fixture",
        tui: { keymap: { "ctrl+x": "teleport" } },
      }),
    );
    await expect(
      resolveAgentConfig(root, {
        globalConfigPath: global,
        projectConfigPath: join(root, "missing.json"),
      }),
    ).rejects.toThrow("Invalid TUI action");
  });

  it("discovers instructions, skills, prompts and extensions only when trusted", async () => {
    const root = await createTestDirectory("agent-resources");
    const home = await createTestDirectory("agent-home");
    await mkdir(join(root, ".focuscode", "skills", "review"), { recursive: true });
    await mkdir(join(root, ".focuscode", "prompts"), { recursive: true });
    await mkdir(join(root, ".focuscode", "extensions"), { recursive: true });
    await writeFile(join(root, "AGENTS.md"), "Use small changes.\n");
    await writeFile(
      join(root, ".focuscode", "skills", "review", "SKILL.md"),
      "---\nname: review\ndescription: Review changes\n---\nCheck the diff.\n",
    );
    await writeFile(
      join(root, ".focuscode", "prompts", "fix.md"),
      "---\ndescription: Fix a bug\n---\nFix: $ARGUMENTS\n",
    );
    const extensionPath = join(root, ".focuscode", "extensions", "fixture.mjs");
    await writeFile(
      extensionPath,
      `export const name = "fixture";
export default function(api) {
  api.appendSystemPrompt("extension prompt");
  api.registerCommand({name:"hello",description:"hello",execute:(args)=>"hi "+args});
  api.registerTool({definition:{name:"fixture_tool",label:"Fixture",description:"fixture",parameters:{type:"object"},effect:"read"},execute:async()=>({content:"fixture result"})});
}`,
    );
    await writeFile(join(root, "attached.txt"), "attachment body\n");
    const resources = await loadAgentResources({
      cwd: root,
      projectTrusted: true,
      homeDirectory: home,
    });
    expect(resources.instructions.map((item) => item.path)).toContain(join(root, "AGENTS.md"));
    expect(resources.skills).toMatchObject([{ name: "review", description: "Review changes" }]);
    expect(expandPromptTemplate(resources.prompts[0]!, "issue")).toContain("Fix: issue");
    expect(renderResourcePrompt(resources)).toContain("Use small changes");
    expect(await expandFileMentions(root, "inspect @attached.txt")).toContain("attachment body");

    const registry = new AgentToolRegistry();
    const host = new ExtensionHost(registry);
    expect(await host.load(resources.extensionPaths)).toMatchObject([{ name: "fixture" }]);
    expect(registry.get("fixture_tool")).toBeDefined();
    expect(await host.getCommand("hello")?.execute("world", { sessionId: "s", cwd: root })).toBe(
      "hi world",
    );
    expect(host.systemPrompt()).toContain("extension prompt");
    expect(await host.reload()).toHaveLength(1);
    expect(registry.get("fixture_tool")).toBeDefined();

    const untrusted = await loadAgentResources({
      cwd: root,
      projectTrusted: false,
      homeDirectory: home,
    });
    expect(untrusted.skills).toEqual([]);
    expect(untrusted.extensionPaths).toEqual([]);
  });
});
