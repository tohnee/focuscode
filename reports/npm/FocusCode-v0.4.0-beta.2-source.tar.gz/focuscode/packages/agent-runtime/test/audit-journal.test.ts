import { readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { createTestDirectory } from "@focuscode/testkit";
import { FileAuditJournal, verifyAuditJournal } from "../src/index.js";

describe("enterprise audit journal", () => {
  it("writes a redacted HMAC chain and detects tampering", async () => {
    const directory = await createTestDirectory("agent-audit");
    const key = "k".repeat(48);
    const journal = new FileAuditJournal({
      directory,
      hmacKey: key,
      now: () => new Date("2026-01-01T00:00:00Z"),
    });
    await journal.record("session_fixture", { type: "text_delta", delta: "secret response" });
    await journal.record("session_fixture", {
      type: "tool_end",
      call: { id: "c1", name: "bash", arguments: { command: "echo secret" } },
      result: { content: "credential=secret" },
      durationMs: 4,
    });
    const path = join(directory, "session_fixture.audit.jsonl");
    const source = await readFile(path, "utf8");
    expect(source).not.toContain("secret response");
    expect(source).not.toContain("credential=secret");
    await expect(verifyAuditJournal(path, key)).resolves.toMatchObject({ records: 2 });
    await writeFile(path, source.replace('"durationMs":4', '"durationMs":5'));
    await expect(verifyAuditJournal(path, key)).rejects.toThrow("signature");
  });

  it("requires a strong audit key", () => {
    expect(() => new FileAuditJournal({ directory: "/tmp/focus-audit", hmacKey: "short" })).toThrow(
      "32 bytes",
    );
  });
});
