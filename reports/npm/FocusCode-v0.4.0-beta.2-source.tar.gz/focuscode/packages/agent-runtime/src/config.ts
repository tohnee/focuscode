import { constants } from "node:fs";
import { access, readFile } from "node:fs/promises";
import { homedir } from "node:os";
import { join, resolve } from "node:path";
import type {
  ApprovalMode,
  ModelCapabilities,
  ModelProfile,
  ModelReliabilityPolicy,
  ProviderCompatibility,
  ReasoningEffort,
} from "./types.js";

export interface ProviderPreset {
  id: string;
  protocol: ModelProfile["protocol"];
  baseUrl: string;
  apiKeyEnv?: string;
  defaultAuthType?: ModelProfile["authType"];
  defaultModel?: string;
  defaultContextWindow: number;
  defaultMaxOutputTokens: number;
  defaultReasoningEffort?: ReasoningEffort;
  capabilities?: ModelCapabilities;
  compatibility?: ProviderCompatibility;
  reliability?: Partial<ModelReliabilityPolicy>;
  extraHeaders?: Record<string, string>;
}

export interface ModelProfilePreset {
  protocol?: ModelProfile["protocol"];
  baseUrl?: string;
  apiKeyEnv?: string;
  authType?: ModelProfile["authType"];
  contextWindow?: number;
  maxOutputTokens?: number;
  temperature?: number;
  reasoningEffort?: ReasoningEffort;
  toolMode?: ModelProfile["toolMode"];
  capabilities?: ModelCapabilities;
  compatibility?: ProviderCompatibility;
  reliability?: Partial<ModelReliabilityPolicy>;
  extraHeaders?: Record<string, string>;
}

export interface AgentConfigFile {
  schemaVersion?: "focuscode-agent.v1";
  provider?: string;
  model?: string;
  protocol?: ModelProfile["protocol"];
  baseUrl?: string;
  apiKeyEnv?: string;
  authType?: ModelProfile["authType"];
  oauthAccount?: string;
  contextWindow?: number;
  maxOutputTokens?: number;
  temperature?: number;
  reasoningEffort?: ReasoningEffort;
  toolMode?: ModelProfile["toolMode"];
  approval?: ApprovalMode;
  maxRounds?: number;
  steeringMaximum?: number;
  protectedPaths?: string[];
  instructions?: string[];
  enabledTools?: string[];
  disabledTools?: string[];
  providers?: Record<string, Partial<ProviderPreset>>;
  models?: Record<string, ModelProfilePreset>;
  sandbox?: {
    kind?: "host" | "docker" | "gvisor" | "vm" | "auto";
    image?: string;
    network?: "none" | "bridge";
    allowHostFallback?: boolean;
    requireImageDigest?: boolean;
    vmHost?: string;
    vmWorkspace?: string;
    vmIdentityFile?: string;
  };
  tui?: {
    enabled?: boolean;
    title?: string;
    theme?: string;
    mascot?: string;
    keymap?: Record<string, string>;
  };
  media?: {
    allowRemoteImages?: boolean;
  };
  enterprise?: {
    enabled?: boolean;
    allowedProviders?: string[];
    allowedModels?: string[];
    requireIsolatedSandbox?: boolean;
    auditDirectory?: string;
    auditHmacKeyEnv?: string;
    allowProjectExtensions?: boolean;
    allowedExtensions?: string[];
  };
  extensionDirectory?: string;
  requireExtensionSignatures?: boolean;
  shareEndpoint?: string;
}

export interface AgentConfigOverrides extends AgentConfigFile {
  apiKey?: string;
  projectTrusted?: boolean;
  globalConfigPath?: string;
  projectConfigPath?: string;
}

export interface ResolvedAgentConfig {
  model: ModelProfile;
  approval: ApprovalMode;
  maxRounds: number;
  projectTrusted: boolean;
  protectedPaths: string[];
  instructions: string[];
  enabledTools?: string[];
  disabledTools: string[];
  sandbox: NonNullable<AgentConfigFile["sandbox"]>;
  tui: NonNullable<AgentConfigFile["tui"]>;
  media: NonNullable<AgentConfigFile["media"]>;
  enterprise: NonNullable<AgentConfigFile["enterprise"]>;
  steeringMaximum: number;
  extensionDirectory?: string;
  requireExtensionSignatures: boolean;
  shareEndpoint?: string;
  sources: string[];
}

const PRESETS: Record<string, ProviderPreset> = {
  openai: {
    id: "openai",
    protocol: "openai-responses",
    baseUrl: "https://api.openai.com/v1",
    apiKeyEnv: "OPENAI_API_KEY",
    capabilities: { input: ["text", "image"], reasoning: true, toolCalling: true },
    defaultContextWindow: 128_000,
    defaultMaxOutputTokens: 16_384,
  },
  anthropic: {
    id: "anthropic",
    protocol: "anthropic-messages",
    baseUrl: "https://api.anthropic.com/v1",
    apiKeyEnv: "ANTHROPIC_API_KEY",
    capabilities: { input: ["text", "image"], reasoning: true, toolCalling: true },
    defaultContextWindow: 200_000,
    defaultMaxOutputTokens: 16_384,
  },
  gemini: {
    id: "gemini",
    protocol: "google-gemini",
    baseUrl: "https://generativelanguage.googleapis.com/v1beta",
    apiKeyEnv: "GEMINI_API_KEY",
    capabilities: { input: ["text", "image"], reasoning: true, toolCalling: true },
    defaultContextWindow: 1_000_000,
    defaultMaxOutputTokens: 65_536,
  },
  deepseek: {
    id: "deepseek",
    protocol: "openai-chat",
    baseUrl: "https://api.deepseek.com",
    apiKeyEnv: "DEEPSEEK_API_KEY",
    defaultModel: "deepseek-v4-pro",
    defaultContextWindow: 1_000_000,
    defaultMaxOutputTokens: 384_000,
    defaultReasoningEffort: "high",
    capabilities: { input: ["text"], reasoning: true, toolCalling: true },
    compatibility: {
      thinkingFormat: "deepseek",
      requiresReasoningContentOnAssistantMessages: true,
      requiresAssistantContentForToolCalls: true,
      supportsReasoningEffort: true,
      supportsToolChoice: false,
      supportsTemperature: false,
      reasoningEffortMap: {
        minimal: "high",
        low: "high",
        medium: "high",
        high: "high",
        max: "max",
      },
    },
  },
  openrouter: {
    id: "openrouter",
    protocol: "openai-chat",
    baseUrl: "https://openrouter.ai/api/v1",
    apiKeyEnv: "OPENROUTER_API_KEY",
    defaultContextWindow: 128_000,
    defaultMaxOutputTokens: 16_384,
  },
  qwen: {
    id: "qwen",
    protocol: "openai-chat",
    baseUrl: "https://dashscope.aliyuncs.com/compatible-mode/v1",
    apiKeyEnv: "DASHSCOPE_API_KEY",
    defaultModel: "qwen3-coder-plus",
    defaultContextWindow: 1_000_000,
    defaultMaxOutputTokens: 65_536,
    defaultReasoningEffort: "high",
    capabilities: { input: ["text"], reasoning: true, toolCalling: true },
    compatibility: { thinkingFormat: "qwen", supportsReasoningEffort: true },
  },
  "qwen-intl": {
    id: "qwen-intl",
    protocol: "openai-chat",
    baseUrl: "https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
    apiKeyEnv: "DASHSCOPE_API_KEY",
    defaultModel: "qwen3-coder-plus",
    defaultContextWindow: 1_000_000,
    defaultMaxOutputTokens: 65_536,
    defaultReasoningEffort: "high",
    capabilities: { input: ["text"], reasoning: true, toolCalling: true },
    compatibility: { thinkingFormat: "qwen", supportsReasoningEffort: true },
  },
  kimi: {
    id: "kimi",
    protocol: "openai-chat",
    baseUrl: "https://api.moonshot.ai/v1",
    apiKeyEnv: "MOONSHOT_API_KEY",
    defaultModel: "kimi-k3",
    defaultContextWindow: 1_048_576,
    defaultMaxOutputTokens: 131_072,
    defaultReasoningEffort: "max",
    capabilities: { input: ["text", "image"], reasoning: true, toolCalling: true },
    compatibility: {
      thinkingFormat: "openai",
      requiresReasoningContentOnAssistantMessages: true,
      requiresAssistantContentForToolCalls: true,
      supportsReasoningEffort: true,
      reasoningEffortMap: {
        minimal: "max",
        low: "max",
        medium: "max",
        high: "max",
        max: "max",
      },
    },
  },
  "kimi-cn": {
    id: "kimi-cn",
    protocol: "openai-chat",
    baseUrl: "https://api.moonshot.cn/v1",
    apiKeyEnv: "MOONSHOT_API_KEY",
    defaultModel: "kimi-k3",
    defaultContextWindow: 1_048_576,
    defaultMaxOutputTokens: 131_072,
    defaultReasoningEffort: "max",
    capabilities: { input: ["text", "image"], reasoning: true, toolCalling: true },
    compatibility: {
      thinkingFormat: "openai",
      requiresReasoningContentOnAssistantMessages: true,
      requiresAssistantContentForToolCalls: true,
      supportsReasoningEffort: true,
      reasoningEffortMap: {
        minimal: "max",
        low: "max",
        medium: "max",
        high: "max",
        max: "max",
      },
    },
  },
  moonshot: {
    id: "moonshot",
    protocol: "openai-chat",
    baseUrl: "https://api.moonshot.cn/v1",
    apiKeyEnv: "MOONSHOT_API_KEY",
    defaultModel: "kimi-k3",
    defaultContextWindow: 1_048_576,
    defaultMaxOutputTokens: 131_072,
    defaultReasoningEffort: "max",
    capabilities: { input: ["text", "image"], reasoning: true, toolCalling: true },
    compatibility: {
      thinkingFormat: "openai",
      requiresReasoningContentOnAssistantMessages: true,
      requiresAssistantContentForToolCalls: true,
      supportsReasoningEffort: true,
      reasoningEffortMap: {
        minimal: "max",
        low: "max",
        medium: "max",
        high: "max",
        max: "max",
      },
    },
  },
  "kimi-coding": {
    id: "kimi-coding",
    protocol: "anthropic-messages",
    baseUrl: "https://api.kimi.com/coding",
    apiKeyEnv: "KIMI_API_KEY",
    defaultModel: "k3",
    defaultContextWindow: 262_144,
    defaultMaxOutputTokens: 32_768,
    capabilities: { input: ["text", "image"], reasoning: true, toolCalling: true },
    extraHeaders: { "user-agent": "KimiCLI/1.5" },
  },
  glm: {
    id: "glm",
    protocol: "openai-chat",
    baseUrl: "https://api.z.ai/api/coding/paas/v4",
    apiKeyEnv: "ZAI_API_KEY",
    defaultModel: "glm-5.2",
    defaultContextWindow: 1_000_000,
    defaultMaxOutputTokens: 131_072,
    defaultReasoningEffort: "high",
    capabilities: { input: ["text"], reasoning: true, toolCalling: true },
    compatibility: {
      thinkingFormat: "zai",
      supportsReasoningEffort: true,
      zaiToolStream: true,
    },
  },
  "glm-cn": {
    id: "glm-cn",
    protocol: "openai-chat",
    baseUrl: "https://open.bigmodel.cn/api/coding/paas/v4",
    apiKeyEnv: "ZAI_API_KEY",
    defaultModel: "glm-5.2",
    defaultContextWindow: 1_000_000,
    defaultMaxOutputTokens: 131_072,
    defaultReasoningEffort: "high",
    capabilities: { input: ["text"], reasoning: true, toolCalling: true },
    compatibility: {
      thinkingFormat: "zai",
      supportsReasoningEffort: true,
      zaiToolStream: true,
    },
  },
  minimax: {
    id: "minimax",
    protocol: "anthropic-messages",
    baseUrl: "https://api.minimax.io/anthropic",
    apiKeyEnv: "MINIMAX_API_KEY",
    defaultModel: "MiniMax-M3",
    defaultContextWindow: 1_000_000,
    defaultMaxOutputTokens: 131_072,
    capabilities: { input: ["text", "image"], reasoning: true, toolCalling: true },
    compatibility: { anthropicThinking: "adaptive" },
  },
  "minimax-cn": {
    id: "minimax-cn",
    protocol: "anthropic-messages",
    baseUrl: "https://api.minimaxi.com/anthropic",
    apiKeyEnv: "MINIMAX_API_KEY",
    defaultModel: "MiniMax-M3",
    defaultContextWindow: 1_000_000,
    defaultMaxOutputTokens: 131_072,
    capabilities: { input: ["text", "image"], reasoning: true, toolCalling: true },
    compatibility: { anthropicThinking: "adaptive" },
  },
  ollama: {
    id: "ollama",
    protocol: "openai-chat",
    baseUrl: "http://127.0.0.1:11434/v1",
    defaultContextWindow: 32_768,
    defaultMaxOutputTokens: 8_192,
  },
  llamacpp: {
    id: "llamacpp",
    protocol: "openai-chat",
    baseUrl: "http://127.0.0.1:8080/v1",
    defaultContextWindow: 32_768,
    defaultMaxOutputTokens: 8_192,
  },
  vllm: {
    id: "vllm",
    protocol: "openai-chat",
    baseUrl: "http://127.0.0.1:8000/v1",
    defaultContextWindow: 128_000,
    defaultMaxOutputTokens: 16_384,
  },
  lmstudio: {
    id: "lmstudio",
    protocol: "openai-chat",
    baseUrl: "http://127.0.0.1:1234/v1",
    defaultContextWindow: 128_000,
    defaultMaxOutputTokens: 16_384,
  },
  sglang: {
    id: "sglang",
    protocol: "openai-chat",
    baseUrl: "http://127.0.0.1:30000/v1",
    defaultContextWindow: 128_000,
    defaultMaxOutputTokens: 16_384,
  },
  groq: {
    id: "groq",
    protocol: "openai-chat",
    baseUrl: "https://api.groq.com/openai/v1",
    apiKeyEnv: "GROQ_API_KEY",
    defaultContextWindow: 128_000,
    defaultMaxOutputTokens: 16_384,
  },
  mistral: {
    id: "mistral",
    protocol: "openai-chat",
    baseUrl: "https://api.mistral.ai/v1",
    apiKeyEnv: "MISTRAL_API_KEY",
    defaultContextWindow: 128_000,
    defaultMaxOutputTokens: 16_384,
  },
  xai: {
    id: "xai",
    protocol: "openai-chat",
    baseUrl: "https://api.x.ai/v1",
    apiKeyEnv: "XAI_API_KEY",
    defaultContextWindow: 256_000,
    defaultMaxOutputTokens: 32_768,
  },
  together: {
    id: "together",
    protocol: "openai-chat",
    baseUrl: "https://api.together.xyz/v1",
    apiKeyEnv: "TOGETHER_API_KEY",
    defaultContextWindow: 128_000,
    defaultMaxOutputTokens: 16_384,
  },
};

const DEFAULT_CAPABILITIES: ModelCapabilities = {
  input: ["text"],
  reasoning: false,
  toolCalling: true,
};

const DEFAULT_COMPATIBILITY: ProviderCompatibility = {
  supportsParallelToolCalls: true,
  supportsStreamUsage: true,
  supportsToolChoice: true,
  supportsTemperature: true,
  supportsReasoningEffort: false,
  maxTokensField: "max_tokens",
  thinkingFormat: "openai",
  requiresReasoningContentOnAssistantMessages: false,
  requiresToolResultName: false,
  requiresAssistantContentForToolCalls: false,
  zaiToolStream: false,
  reasoningEffortMap: {},
  anthropicThinking: "omit",
  anthropicThinkingBudgetTokens: 16_384,
};

const DEFAULT_RELIABILITY: ModelReliabilityPolicy = {
  timeoutMs: 300_000,
  maxRetries: 2,
  retryBaseDelayMs: 500,
  retryMaximumDelayMs: 10_000,
};

const DEFAULT_PROTECTED_PATHS = [
  ".git",
  ".env",
  ".env.local",
  ".env.production",
  ".npmrc",
  ".pypirc",
  ".ssh",
  "credentials.json",
  "secrets",
  "node_modules",
  ".focuscode",
];

export async function resolveAgentConfig(
  cwd: string,
  overrides: AgentConfigOverrides = {},
): Promise<ResolvedAgentConfig> {
  const projectTrusted = overrides.projectTrusted ?? false;
  const globalPath = resolve(
    overrides.globalConfigPath ?? join(homedir(), ".focuscode", "config.json"),
  );
  const projectPath = resolve(
    overrides.projectConfigPath ?? join(resolve(cwd), ".focuscode", "agent.json"),
  );
  const sources: string[] = [];
  const global = await readConfigIfPresent(globalPath);
  if (global) sources.push(globalPath);
  const project = projectTrusted ? await readConfigIfPresent(projectPath) : undefined;
  if (project) sources.push(projectPath);
  const merged = mergeConfig(global, project, overrides);
  validateAgentConfig(merged, "merged configuration");
  const customPresets = {
    ...(global?.providers ?? {}),
    ...(project?.providers ?? {}),
    ...(overrides.providers ?? {}),
  };
  const providerId = merged.provider ?? inferProviderFromEnvironment() ?? "openai";
  const basePreset = PRESETS[providerId];
  const custom = customPresets[providerId];
  if (!basePreset && !custom && !merged.baseUrl) {
    throw new Error(`Unknown provider ${providerId}; configure baseUrl and protocol`);
  }
  const presetApiKeyEnv = merged.apiKeyEnv ?? custom?.apiKeyEnv ?? basePreset?.apiKeyEnv;
  const preset: ProviderPreset = {
    id: providerId,
    protocol: merged.protocol ?? custom?.protocol ?? basePreset?.protocol ?? "openai-chat",
    baseUrl: merged.baseUrl ?? custom?.baseUrl ?? basePreset?.baseUrl ?? "",
    ...(presetApiKeyEnv ? { apiKeyEnv: presetApiKeyEnv } : {}),
    defaultContextWindow:
      custom?.defaultContextWindow ?? basePreset?.defaultContextWindow ?? 128_000,
    defaultMaxOutputTokens:
      custom?.defaultMaxOutputTokens ?? basePreset?.defaultMaxOutputTokens ?? 16_384,
    ...((custom?.defaultModel ?? basePreset?.defaultModel)
      ? { defaultModel: (custom?.defaultModel ?? basePreset?.defaultModel)! }
      : {}),
    ...((custom?.defaultReasoningEffort ?? basePreset?.defaultReasoningEffort)
      ? {
          defaultReasoningEffort: (custom?.defaultReasoningEffort ??
            basePreset?.defaultReasoningEffort)!,
        }
      : {}),
    capabilities: custom?.capabilities ?? basePreset?.capabilities ?? DEFAULT_CAPABILITIES,
    compatibility: {
      ...DEFAULT_COMPATIBILITY,
      ...basePreset?.compatibility,
      ...custom?.compatibility,
    },
    reliability: {
      ...DEFAULT_RELIABILITY,
      ...basePreset?.reliability,
      ...custom?.reliability,
    },
    extraHeaders: { ...basePreset?.extraHeaders, ...custom?.extraHeaders },
    ...((merged.authType ?? custom?.defaultAuthType ?? basePreset?.defaultAuthType)
      ? {
          defaultAuthType:
            merged.authType ?? custom?.defaultAuthType ?? basePreset?.defaultAuthType,
        }
      : {}),
  };
  const modelId = merged.model ?? process.env.FOCUSCODE_MODEL ?? preset.defaultModel;
  if (!modelId) {
    throw new Error("No model selected. Use --model, FOCUSCODE_MODEL, or config.json");
  }
  const modelPreset = merged.models?.[`${providerId}/${modelId}`] ?? merged.models?.[modelId] ?? {};
  const modelBaseUrl = modelPreset.baseUrl ?? preset.baseUrl;
  if (!modelBaseUrl) throw new Error(`Provider ${providerId} has no baseUrl`);
  const modelApiKeyEnv = modelPreset.apiKeyEnv ?? preset.apiKeyEnv;
  const apiKey =
    overrides.apiKey ??
    process.env.FOCUSCODE_API_KEY ??
    (modelApiKeyEnv ? process.env[modelApiKeyEnv] : undefined);
  const authType = merged.authType ?? modelPreset.authType ?? preset.defaultAuthType ?? "api-key";
  if (modelApiKeyEnv && !apiKey && authType === "api-key" && !merged.oauthAccount) {
    throw new Error(`Provider ${providerId} requires ${modelApiKeyEnv}; set it or pass --api-key`);
  }
  const model: ModelProfile = {
    provider: providerId,
    model: modelId,
    protocol: modelPreset.protocol ?? preset.protocol,
    baseUrl: modelBaseUrl,
    ...(apiKey ? { apiKey } : {}),
    ...(modelApiKeyEnv ? { apiKeyEnv: modelApiKeyEnv } : {}),
    authType: merged.oauthAccount ? "bearer" : authType,
    ...(merged.oauthAccount ? { oauthAccount: merged.oauthAccount } : {}),
    contextWindow: boundedInteger(
      merged.contextWindow ?? modelPreset.contextWindow,
      preset.defaultContextWindow,
      4_096,
      4_000_000,
    ),
    maxOutputTokens: boundedInteger(
      merged.maxOutputTokens ?? modelPreset.maxOutputTokens,
      preset.defaultMaxOutputTokens,
      256,
      512_000,
    ),
    temperature: boundedNumber(merged.temperature ?? modelPreset.temperature, 0, 0, 2),
    toolMode: validToolMode(merged.toolMode ?? modelPreset.toolMode)
      ? (merged.toolMode ?? modelPreset.toolMode)!
      : "auto",
    reasoningEffort:
      merged.reasoningEffort ??
      modelPreset.reasoningEffort ??
      preset.defaultReasoningEffort ??
      ((modelPreset.capabilities ?? preset.capabilities)?.reasoning ? "medium" : "off"),
    capabilities: cloneCapabilities(
      modelPreset.capabilities ?? preset.capabilities ?? DEFAULT_CAPABILITIES,
    ),
    compatibility: {
      ...DEFAULT_COMPATIBILITY,
      ...preset.compatibility,
      ...modelPreset.compatibility,
    },
    reliability: {
      ...DEFAULT_RELIABILITY,
      ...preset.reliability,
      ...modelPreset.reliability,
      timeoutMs: boundedInteger(
        modelPreset.reliability?.timeoutMs ?? preset.reliability?.timeoutMs,
        DEFAULT_RELIABILITY.timeoutMs,
        1_000,
        1_800_000,
      ),
      maxRetries: boundedInteger(
        modelPreset.reliability?.maxRetries ?? preset.reliability?.maxRetries,
        DEFAULT_RELIABILITY.maxRetries,
        0,
        10,
      ),
      retryBaseDelayMs: boundedInteger(
        modelPreset.reliability?.retryBaseDelayMs ?? preset.reliability?.retryBaseDelayMs,
        DEFAULT_RELIABILITY.retryBaseDelayMs,
        10,
        60_000,
      ),
      retryMaximumDelayMs: boundedInteger(
        modelPreset.reliability?.retryMaximumDelayMs ?? preset.reliability?.retryMaximumDelayMs,
        DEFAULT_RELIABILITY.retryMaximumDelayMs,
        10,
        300_000,
      ),
    },
    ...((preset.extraHeaders || modelPreset.extraHeaders) &&
    Object.keys({ ...preset.extraHeaders, ...modelPreset.extraHeaders }).length
      ? { extraHeaders: { ...preset.extraHeaders, ...modelPreset.extraHeaders } }
      : {}),
  };
  const enterpriseEnabled = merged.enterprise?.enabled ?? false;
  enforceEnterprisePolicy(merged, providerId, modelId);
  return {
    model,
    approval: validApproval(merged.approval) ? merged.approval : "ask",
    maxRounds: boundedInteger(merged.maxRounds, 40, 1, 200),
    steeringMaximum: boundedInteger(merged.steeringMaximum, 32, 1, 1_000),
    projectTrusted,
    protectedPaths: [...new Set([...DEFAULT_PROTECTED_PATHS, ...(merged.protectedPaths ?? [])])],
    instructions: merged.instructions ?? [],
    ...(merged.enabledTools ? { enabledTools: merged.enabledTools } : {}),
    disabledTools: merged.disabledTools ?? [],
    sandbox: {
      kind: merged.sandbox?.kind ?? "auto",
      image: merged.sandbox?.image ?? "node:22-bookworm",
      network: merged.sandbox?.network ?? "none",
      allowHostFallback: merged.sandbox?.allowHostFallback ?? false,
      requireImageDigest: merged.sandbox?.requireImageDigest ?? enterpriseEnabled,
      ...(merged.sandbox?.vmHost ? { vmHost: merged.sandbox.vmHost } : {}),
      ...(merged.sandbox?.vmWorkspace ? { vmWorkspace: merged.sandbox.vmWorkspace } : {}),
      ...(merged.sandbox?.vmIdentityFile ? { vmIdentityFile: merged.sandbox.vmIdentityFile } : {}),
    },
    tui: {
      enabled: merged.tui?.enabled ?? true,
      title: merged.tui?.title ?? "FocusCode",
      theme: merged.tui?.theme ?? "aurora",
      mascot: merged.tui?.mascot ?? "mochi",
      keymap: merged.tui?.keymap ?? {},
    },
    media: {
      allowRemoteImages: merged.media?.allowRemoteImages ?? !enterpriseEnabled,
    },
    enterprise: {
      enabled: enterpriseEnabled,
      allowedProviders: merged.enterprise?.allowedProviders ?? [],
      allowedModels: merged.enterprise?.allowedModels ?? [],
      requireIsolatedSandbox: merged.enterprise?.requireIsolatedSandbox ?? true,
      auditDirectory: merged.enterprise?.auditDirectory ?? join(homedir(), ".focuscode", "audit"),
      auditHmacKeyEnv: merged.enterprise?.auditHmacKeyEnv ?? "FOCUSCODE_AUDIT_HMAC_KEY",
      allowProjectExtensions: merged.enterprise?.allowProjectExtensions ?? false,
      allowedExtensions: merged.enterprise?.allowedExtensions ?? [],
    },
    ...(merged.extensionDirectory ? { extensionDirectory: merged.extensionDirectory } : {}),
    requireExtensionSignatures: merged.requireExtensionSignatures ?? true,
    ...(merged.shareEndpoint ? { shareEndpoint: merged.shareEndpoint } : {}),
    sources,
  };
}

export function listProviderPresets(): ProviderPreset[] {
  return Object.values(PRESETS).map((preset) => ({ ...preset }));
}

async function readConfigIfPresent(path: string): Promise<AgentConfigFile | undefined> {
  if (!(await exists(path))) return undefined;
  const value: unknown = JSON.parse(await readFile(path, "utf8"));
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error(`Agent config must be an object: ${path}`);
  }
  const config = value as AgentConfigFile;
  if (config.schemaVersion && config.schemaVersion !== "focuscode-agent.v1") {
    throw new Error(`Unsupported agent config schema in ${path}`);
  }
  validateStringArray(config.protectedPaths, "protectedPaths", path);
  validateStringArray(config.instructions, "instructions", path);
  validateStringArray(config.enabledTools, "enabledTools", path);
  validateStringArray(config.disabledTools, "disabledTools", path);
  validateAgentConfig(config, path);
  return config;
}

function mergeConfig(...configs: Array<AgentConfigFile | undefined>): AgentConfigFile {
  const merged: AgentConfigFile = {};
  for (const config of configs) {
    if (!config) continue;
    for (const [key, value] of Object.entries(config)) {
      if (key === "sandbox" && value && typeof value === "object") {
        merged.sandbox = { ...merged.sandbox, ...(value as AgentConfigFile["sandbox"]) };
        continue;
      }
      if (key === "tui" && value && typeof value === "object") {
        merged.tui = { ...merged.tui, ...(value as AgentConfigFile["tui"]) };
        continue;
      }
      if (key === "media" && value && typeof value === "object") {
        merged.media = { ...merged.media, ...(value as AgentConfigFile["media"]) };
        continue;
      }
      if (key === "enterprise" && value && typeof value === "object") {
        merged.enterprise = {
          ...merged.enterprise,
          ...(value as AgentConfigFile["enterprise"]),
        };
        continue;
      }
      if (key === "providers" && value && typeof value === "object") {
        merged.providers = {
          ...merged.providers,
          ...(value as AgentConfigFile["providers"]),
        };
        continue;
      }
      if (key === "models" && value && typeof value === "object") {
        merged.models = {
          ...merged.models,
          ...(value as AgentConfigFile["models"]),
        };
        continue;
      }
      if (
        value !== undefined &&
        !["apiKey", "projectTrusted", "globalConfigPath", "projectConfigPath"].includes(key)
      ) {
        (merged as Record<string, unknown>)[key] = value;
      }
    }
  }
  return merged;
}

function inferProviderFromEnvironment(): string | undefined {
  if (process.env.ANTHROPIC_API_KEY) return "anthropic";
  if (process.env.OPENAI_API_KEY) return "openai";
  if (process.env.DEEPSEEK_API_KEY) return "deepseek";
  if (process.env.OPENROUTER_API_KEY) return "openrouter";
  if (process.env.DASHSCOPE_API_KEY) return "qwen";
  if (process.env.KIMI_API_KEY) return "kimi-coding";
  if (process.env.MOONSHOT_API_KEY) return "kimi";
  if (process.env.ZAI_API_KEY) return "glm";
  if (process.env.MINIMAX_API_KEY) return "minimax";
  if (process.env.GEMINI_API_KEY) return "gemini";
  return undefined;
}

async function exists(path: string): Promise<boolean> {
  try {
    await access(path, constants.F_OK);
    return true;
  } catch {
    return false;
  }
}

function validateStringArray(value: unknown, label: string, path: string): void {
  if (
    value !== undefined &&
    (!Array.isArray(value) || !value.every((item) => typeof item === "string"))
  ) {
    throw new Error(`${label} must be a string array in ${path}`);
  }
}

function validateAgentConfig(config: AgentConfigFile, path: string): void {
  validateEnum(
    config.protocol,
    ["openai-chat", "openai-responses", "anthropic-messages", "google-gemini"],
    "protocol",
    path,
  );
  validateEnum(config.authType, ["api-key", "bearer", "none"], "authType", path);
  validateEnum(config.toolMode, ["native", "prompt-json", "auto"], "toolMode", path);
  validateEnum(config.approval, ["ask", "auto-edit", "full-auto", "deny"], "approval", path);
  validateEnum(
    config.reasoningEffort,
    ["off", "minimal", "low", "medium", "high", "max"],
    "reasoningEffort",
    path,
  );
  for (const [label, value] of [
    ["provider", config.provider],
    ["model", config.model],
    ["apiKeyEnv", config.apiKeyEnv],
    ["oauthAccount", config.oauthAccount],
    ["extensionDirectory", config.extensionDirectory],
  ] as const) {
    validateOptionalString(value, label, path);
  }
  validateHttpUrl(config.baseUrl, "baseUrl", path);
  validateHttpUrl(config.shareEndpoint, "shareEndpoint", path);
  for (const [label, value] of [
    ["contextWindow", config.contextWindow],
    ["maxOutputTokens", config.maxOutputTokens],
    ["temperature", config.temperature],
    ["maxRounds", config.maxRounds],
    ["steeringMaximum", config.steeringMaximum],
  ] as const) {
    if (value !== undefined && (typeof value !== "number" || !Number.isFinite(value))) {
      throw new Error(`${label} must be a finite number in ${path}`);
    }
  }
  if (
    config.requireExtensionSignatures !== undefined &&
    typeof config.requireExtensionSignatures !== "boolean"
  ) {
    throw new Error(`requireExtensionSignatures must be boolean in ${path}`);
  }
  if (config.sandbox !== undefined) {
    if (!config.sandbox || typeof config.sandbox !== "object" || Array.isArray(config.sandbox)) {
      throw new Error(`sandbox must be an object in ${path}`);
    }
    validateEnum(
      config.sandbox.kind,
      ["host", "docker", "gvisor", "vm", "auto"],
      "sandbox.kind",
      path,
    );
    validateEnum(config.sandbox.network, ["none", "bridge"], "sandbox.network", path);
    validateOptionalString(config.sandbox.image, "sandbox.image", path);
    validateOptionalString(config.sandbox.vmHost, "sandbox.vmHost", path);
    validateOptionalString(config.sandbox.vmWorkspace, "sandbox.vmWorkspace", path);
    validateOptionalString(config.sandbox.vmIdentityFile, "sandbox.vmIdentityFile", path);
    if (
      config.sandbox.allowHostFallback !== undefined &&
      typeof config.sandbox.allowHostFallback !== "boolean"
    ) {
      throw new Error(`sandbox.allowHostFallback must be boolean in ${path}`);
    }
    validateOptionalBoolean(config.sandbox.requireImageDigest, "sandbox.requireImageDigest", path);
    if (config.sandbox.kind === "vm") {
      if (!config.sandbox.vmHost || !config.sandbox.vmWorkspace) {
        throw new Error(`VM sandbox requires vmHost and vmWorkspace in ${path}`);
      }
      if (!config.sandbox.vmWorkspace.startsWith("/")) {
        throw new Error(`sandbox.vmWorkspace must be absolute in ${path}`);
      }
    }
  }
  if (config.tui !== undefined) {
    if (!config.tui || typeof config.tui !== "object" || Array.isArray(config.tui)) {
      throw new Error(`tui must be an object in ${path}`);
    }
    if (config.tui.enabled !== undefined && typeof config.tui.enabled !== "boolean") {
      throw new Error(`tui.enabled must be boolean in ${path}`);
    }
    validateOptionalString(config.tui.theme, "tui.theme", path);
    validateOptionalString(config.tui.mascot, "tui.mascot", path);
    validateOptionalString(config.tui.title, "tui.title", path);
    if (config.tui.keymap !== undefined) {
      if (
        !config.tui.keymap ||
        typeof config.tui.keymap !== "object" ||
        Array.isArray(config.tui.keymap)
      ) {
        throw new Error(`tui.keymap must be an object in ${path}`);
      }
      const actions = new Set([
        "submit",
        "newline",
        "abort",
        "exit",
        "clear",
        "backspace",
        "delete_word",
        "cursor_left",
        "cursor_right",
        "history_previous",
        "history_next",
        "scroll_up",
        "scroll_down",
        "cycle_theme",
        "cycle_mascot",
      ]);
      for (const [key, action] of Object.entries(config.tui.keymap)) {
        if (!/^(ctrl\+[a-z]|enter|backspace|left|right|up|down|pageup|pagedown)$/.test(key)) {
          throw new Error(`Invalid TUI key ${key} in ${path}`);
        }
        if (typeof action !== "string" || !actions.has(action)) {
          throw new Error(`Invalid TUI action for ${key} in ${path}`);
        }
      }
    }
  }
  if (config.media !== undefined) {
    if (!config.media || typeof config.media !== "object" || Array.isArray(config.media)) {
      throw new Error(`media must be an object in ${path}`);
    }
    validateOptionalBoolean(config.media.allowRemoteImages, "media.allowRemoteImages", path);
  }
  if (config.enterprise !== undefined) {
    if (
      !config.enterprise ||
      typeof config.enterprise !== "object" ||
      Array.isArray(config.enterprise)
    ) {
      throw new Error(`enterprise must be an object in ${path}`);
    }
    validateOptionalBoolean(config.enterprise.enabled, "enterprise.enabled", path);
    validateOptionalBoolean(
      config.enterprise.requireIsolatedSandbox,
      "enterprise.requireIsolatedSandbox",
      path,
    );
    validateOptionalBoolean(
      config.enterprise.allowProjectExtensions,
      "enterprise.allowProjectExtensions",
      path,
    );
    validateStringArray(config.enterprise.allowedProviders, "enterprise.allowedProviders", path);
    validateStringArray(config.enterprise.allowedModels, "enterprise.allowedModels", path);
    validateStringArray(config.enterprise.allowedExtensions, "enterprise.allowedExtensions", path);
    validateOptionalString(config.enterprise.auditDirectory, "enterprise.auditDirectory", path);
    validateOptionalString(config.enterprise.auditHmacKeyEnv, "enterprise.auditHmacKeyEnv", path);
  }
  if (config.providers !== undefined) {
    if (
      !config.providers ||
      typeof config.providers !== "object" ||
      Array.isArray(config.providers)
    ) {
      throw new Error(`providers must be an object in ${path}`);
    }
    for (const [id, preset] of Object.entries(config.providers)) {
      if (!preset || typeof preset !== "object" || Array.isArray(preset)) {
        throw new Error(`Provider ${id} must be an object in ${path}`);
      }
      validateEnum(
        preset.protocol,
        ["openai-chat", "openai-responses", "anthropic-messages", "google-gemini"],
        `providers.${id}.protocol`,
        path,
      );
      validateEnum(
        preset.defaultAuthType,
        ["api-key", "bearer", "none"],
        `providers.${id}.defaultAuthType`,
        path,
      );
      validateHttpUrl(preset.baseUrl, `providers.${id}.baseUrl`, path);
      validateOptionalString(preset.apiKeyEnv, `providers.${id}.apiKeyEnv`, path);
      validateOptionalString(preset.defaultModel, `providers.${id}.defaultModel`, path);
      validateEnum(
        preset.defaultReasoningEffort,
        ["off", "minimal", "low", "medium", "high", "max"],
        `providers.${id}.defaultReasoningEffort`,
        path,
      );
      validateCapabilities(preset.capabilities, `providers.${id}.capabilities`, path);
      validateCompatibility(preset.compatibility, `providers.${id}.compatibility`, path);
      validateReliability(preset.reliability, `providers.${id}.reliability`, path);
      validateStringRecord(preset.extraHeaders, `providers.${id}.extraHeaders`, path);
    }
  }
  if (config.models !== undefined) {
    if (!config.models || typeof config.models !== "object" || Array.isArray(config.models)) {
      throw new Error(`models must be an object in ${path}`);
    }
    for (const [id, profile] of Object.entries(config.models)) {
      validateOptionalString(id, "model profile id", path);
      if (!profile || typeof profile !== "object" || Array.isArray(profile)) {
        throw new Error(`Model profile ${id} must be an object in ${path}`);
      }
      validateEnum(
        profile.protocol,
        ["openai-chat", "openai-responses", "anthropic-messages", "google-gemini"],
        `models.${id}.protocol`,
        path,
      );
      validateEnum(profile.authType, ["api-key", "bearer", "none"], `models.${id}.authType`, path);
      validateEnum(
        profile.reasoningEffort,
        ["off", "minimal", "low", "medium", "high", "max"],
        `models.${id}.reasoningEffort`,
        path,
      );
      validateEnum(
        profile.toolMode,
        ["native", "prompt-json", "auto"],
        `models.${id}.toolMode`,
        path,
      );
      validateHttpUrl(profile.baseUrl, `models.${id}.baseUrl`, path);
      validateOptionalString(profile.apiKeyEnv, `models.${id}.apiKeyEnv`, path);
      for (const [label, value] of [
        ["contextWindow", profile.contextWindow],
        ["maxOutputTokens", profile.maxOutputTokens],
        ["temperature", profile.temperature],
      ] as const) {
        if (value !== undefined && (typeof value !== "number" || !Number.isFinite(value))) {
          throw new Error(`models.${id}.${label} must be a finite number in ${path}`);
        }
      }
      validateCapabilities(profile.capabilities, `models.${id}.capabilities`, path);
      validateCompatibility(profile.compatibility, `models.${id}.compatibility`, path);
      validateReliability(profile.reliability, `models.${id}.reliability`, path);
      validateStringRecord(profile.extraHeaders, `models.${id}.extraHeaders`, path);
    }
  }
}

function validateEnum(
  value: unknown,
  allowed: readonly string[],
  label: string,
  path: string,
): void {
  if (value !== undefined && (typeof value !== "string" || !allowed.includes(value))) {
    throw new Error(`${label} must be one of ${allowed.join(", ")} in ${path}`);
  }
}

function validateOptionalString(value: unknown, label: string, path: string): void {
  if (
    value !== undefined &&
    (typeof value !== "string" || !value.trim() || /[\u0000-\u001f\u007f]/.test(value))
  ) {
    throw new Error(`${label} must be a non-empty string in ${path}`);
  }
}

function validateOptionalBoolean(value: unknown, label: string, path: string): void {
  if (value !== undefined && typeof value !== "boolean") {
    throw new Error(`${label} must be boolean in ${path}`);
  }
}

function validateCapabilities(value: unknown, label: string, path: string): void {
  if (value === undefined) return;
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error(`${label} must be an object in ${path}`);
  }
  const capabilities = value as Partial<ModelCapabilities>;
  if (
    !Array.isArray(capabilities.input) ||
    capabilities.input.length === 0 ||
    !capabilities.input.every((item) => item === "text" || item === "image")
  ) {
    throw new Error(`${label}.input must contain text and/or image in ${path}`);
  }
  validateOptionalBoolean(capabilities.reasoning, `${label}.reasoning`, path);
  validateOptionalBoolean(capabilities.toolCalling, `${label}.toolCalling`, path);
}

function validateCompatibility(value: unknown, label: string, path: string): void {
  if (value === undefined) return;
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error(`${label} must be an object in ${path}`);
  }
  const compatibility = value as ProviderCompatibility;
  for (const [key, item] of Object.entries(compatibility)) {
    if (
      [
        "maxTokensField",
        "thinkingFormat",
        "reasoningEffortMap",
        "anthropicThinking",
        "anthropicThinkingBudgetTokens",
      ].includes(key)
    )
      continue;
    validateOptionalBoolean(item, `${label}.${key}`, path);
  }
  validateEnum(
    compatibility.maxTokensField,
    ["max_tokens", "max_completion_tokens"],
    `${label}.maxTokensField`,
    path,
  );
  if (compatibility.reasoningEffortMap !== undefined) {
    if (
      !compatibility.reasoningEffortMap ||
      typeof compatibility.reasoningEffortMap !== "object" ||
      Array.isArray(compatibility.reasoningEffortMap)
    ) {
      throw new Error(`${label}.reasoningEffortMap must be an object in ${path}`);
    }
    const efforts = ["off", "minimal", "low", "medium", "high", "max"] as const;
    for (const [source, target] of Object.entries(compatibility.reasoningEffortMap)) {
      if (!efforts.includes(source as (typeof efforts)[number])) {
        throw new Error(`${label}.reasoningEffortMap has invalid source ${source} in ${path}`);
      }
      validateEnum(target, efforts, `${label}.reasoningEffortMap.${source}`, path);
    }
  }
  validateEnum(
    compatibility.thinkingFormat,
    ["openai", "deepseek", "qwen", "zai"],
    `${label}.thinkingFormat`,
    path,
  );
  validateEnum(
    compatibility.anthropicThinking,
    ["omit", "adaptive", "enabled", "disabled"],
    `${label}.anthropicThinking`,
    path,
  );
  if (
    compatibility.anthropicThinkingBudgetTokens !== undefined &&
    (!Number.isInteger(compatibility.anthropicThinkingBudgetTokens) ||
      compatibility.anthropicThinkingBudgetTokens < 1 ||
      compatibility.anthropicThinkingBudgetTokens > 512_000)
  ) {
    throw new Error(`${label}.anthropicThinkingBudgetTokens must be 1..512000 in ${path}`);
  }
}

function validateReliability(value: unknown, label: string, path: string): void {
  if (value === undefined) return;
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error(`${label} must be an object in ${path}`);
  }
  for (const [key, item] of Object.entries(value)) {
    if (typeof item !== "number" || !Number.isInteger(item) || item < 0) {
      throw new Error(`${label}.${key} must be a non-negative integer in ${path}`);
    }
  }
}

function validateStringRecord(value: unknown, label: string, path: string): void {
  if (value === undefined) return;
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error(`${label} must be an object in ${path}`);
  }
  for (const [key, item] of Object.entries(value)) {
    validateOptionalString(key, `${label} key`, path);
    validateOptionalString(item, `${label}.${key}`, path);
  }
}

function validateHttpUrl(value: unknown, label: string, path: string): void {
  if (value === undefined) return;
  validateOptionalString(value, label, path);
  let url: URL;
  try {
    url = new URL(String(value));
  } catch {
    throw new Error(`${label} must be an absolute URL in ${path}`);
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    throw new Error(`${label} must use HTTP or HTTPS in ${path}`);
  }
}

function validApproval(value: unknown): value is ApprovalMode {
  return ["ask", "auto-edit", "full-auto", "deny"].includes(String(value));
}

function validToolMode(value: unknown): value is ModelProfile["toolMode"] {
  return ["native", "prompt-json", "auto"].includes(String(value));
}

function boundedInteger(value: unknown, fallback: number, min: number, max: number): number {
  return typeof value === "number" && Number.isInteger(value)
    ? Math.min(max, Math.max(min, value))
    : fallback;
}

function boundedNumber(value: unknown, fallback: number, min: number, max: number): number {
  return typeof value === "number" && Number.isFinite(value)
    ? Math.min(max, Math.max(min, value))
    : fallback;
}

function cloneCapabilities(value: ModelCapabilities): ModelCapabilities {
  return { ...value, input: [...value.input] };
}

function enforceEnterprisePolicy(config: AgentConfigFile, provider: string, model: string): void {
  if (config.enterprise?.enabled !== true) return;
  const allowedProviders = config.enterprise.allowedProviders ?? [];
  if (allowedProviders.length > 0 && !allowedProviders.includes(provider)) {
    throw new Error(`Enterprise policy denies provider ${provider}`);
  }
  const allowedModels = config.enterprise.allowedModels ?? [];
  const qualifiedModel = `${provider}/${model}`;
  if (
    allowedModels.length > 0 &&
    !allowedModels.includes(model) &&
    !allowedModels.includes(qualifiedModel)
  ) {
    throw new Error(`Enterprise policy denies model ${qualifiedModel}`);
  }
  if (
    (config.enterprise.requireIsolatedSandbox ?? true) &&
    (config.sandbox?.kind === "host" || config.sandbox?.allowHostFallback === true)
  ) {
    throw new Error("Enterprise policy requires an isolated sandbox and forbids host fallback");
  }
  if (
    (config.sandbox?.requireImageDigest ?? true) &&
    config.sandbox?.kind !== "vm" &&
    !/@sha256:[a-f0-9]{64}$/i.test(config.sandbox?.image ?? "node:22-bookworm")
  ) {
    throw new Error("Enterprise policy requires a sandbox image pinned by sha256 digest");
  }
  if (config.requireExtensionSignatures === false) {
    throw new Error("Enterprise policy requires signed extension packages");
  }
  if (config.media?.allowRemoteImages === true) {
    throw new Error(
      "Enterprise policy blocks remote image URLs; use local files or disable enterprise mode",
    );
  }
}
