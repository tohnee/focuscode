import { randomUUID } from "node:crypto";

export interface SteeringItem {
  id: string;
  text: string;
  mode: "append" | "interrupt" | "follow-up";
  createdAt: string;
}

export class SteeringQueue {
  private readonly items: SteeringItem[] = [];

  constructor(
    private readonly maximum = 32,
    private readonly now: () => Date = () => new Date(),
  ) {}

  enqueue(text: string, mode: SteeringItem["mode"] = "append"): SteeringItem {
    const prompt = text.trim();
    if (!prompt) throw new Error("Steering text must not be empty");
    if (this.items.length >= this.maximum) throw new Error("Steering queue is full");
    const item: SteeringItem = {
      id: "steer_" + randomUUID(),
      text: prompt,
      mode,
      createdAt: this.now().toISOString(),
    };
    this.items.push(item);
    return structuredClone(item);
  }

  drain(modes?: SteeringItem["mode"][]): SteeringItem[] {
    if (!modes) return this.items.splice(0).map((item) => structuredClone(item));
    const accepted = new Set(modes);
    const drained = this.items.filter((item) => accepted.has(item.mode));
    const retained = this.items.filter((item) => !accepted.has(item.mode));
    this.items.splice(0, this.items.length, ...retained);
    return drained.map((item) => structuredClone(item));
  }

  list(): SteeringItem[] {
    return this.items.map((item) => structuredClone(item));
  }

  get size(): number {
    return this.items.length;
  }
}
