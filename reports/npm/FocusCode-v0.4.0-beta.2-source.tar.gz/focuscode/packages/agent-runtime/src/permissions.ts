import { relative, resolve, sep } from "node:path";
import { normalizeRelativePath } from "@focuscode/contracts";
import type {
  AgentToolCall,
  ApprovalHandler,
  ApprovalMode,
  PermissionDecision,
  PermissionRequest,
  ToolDefinition,
} from "./types.js";

export interface PermissionControllerOptions {
  cwd: string;
  mode: ApprovalMode;
  projectTrusted: boolean;
  protectedPaths: string[];
  approve?: ApprovalHandler;
}

const CRITICAL_SHELL_PATTERNS: Array<[RegExp, string]> = [
  [
    /\brm\s+(?:-[a-zA-Z]*r[a-zA-Z]*f|-[a-zA-Z]*f[a-zA-Z]*r)\s+(?:\/|~|\$HOME)(?:\s|$)/,
    "recursive deletion of a broad system path",
  ],
  [/\b(?:mkfs(?:\.[a-z0-9]+)?|fdisk|parted)\b/i, "disk formatting or partitioning"],
  [/\bdd\s+[^\n]*\bof=\/dev\//i, "raw device write"],
  [/\b(?:shutdown|reboot|poweroff|halt)\b/i, "host shutdown"],
  [/:\(\)\s*\{\s*:\|:&\s*\}\s*;/, "fork bomb"],
  [
    /\b(?:curl|wget)\b[^\n|;]*(?:\||\$\()[^\n]*(?:sh|bash|zsh|powershell)\b/i,
    "download-and-execute pipeline",
  ],
];

const HIGH_RISK_SHELL_PATTERNS: Array<[RegExp, string]> = [
  [/\bgit\s+reset\s+--hard\b/i, "destructive git reset"],
  [/\bgit\s+clean\s+-[^\s]*f/i, "destructive git clean"],
  [/\bgit\s+(?:push\s+[^\n]*--force|push\s+-f)\b/i, "force push"],
  [/\b(?:sudo|su)\b/i, "privilege escalation"],
  [/\b(?:rm|rmdir|del|erase)\b/i, "file deletion"],
  [/\b(?:chmod|chown)\b/i, "permission or ownership change"],
  [/\b(?:npm|pnpm|yarn|bun)\s+(?:publish|unpublish)\b/i, "package publication"],
  [
    /\b(?:terraform\s+apply|kubectl\s+(?:apply|delete)|docker\s+(?:push|rm))\b/i,
    "external infrastructure mutation",
  ],
];

const READ_ONLY_SHELL = [
  /^\s*(?:pwd|ls|find|fd|rg|grep|cat|head|tail|wc|sed\s+-n|awk|stat|file|which|type)\b/,
  /^\s*git\s+(?:status|diff|log|show|branch|rev-parse|ls-files|grep)\b/,
  /^\s*(?:node|python|python3|ruby|go|rustc|java)\s+--?version\b/,
];

const TRUSTED_PROJECT_COMMAND =
  /^\s*(?:npm|pnpm|yarn|bun|npx|uv|python|python3|pytest|go|cargo|mvn|gradle|make)\s+(?:test|run\s+(?:test|lint|check|build|typecheck)|lint|check|build|typecheck|pytest|vet)(?:\s|$)/;

export class PermissionController {
  readonly mode: ApprovalMode;
  private readonly protectedPaths: string[];

  constructor(private readonly options: PermissionControllerOptions) {
    this.mode = options.mode;
    this.protectedPaths = options.protectedPaths.map(normalizeRelativePath);
  }

  evaluate(tool: ToolDefinition, call: AgentToolCall): PermissionDecision {
    const invalid = call.arguments._invalid;
    if (typeof invalid === "string") return { allowed: false, reason: invalid };

    const sensitive = this.sensitiveResource(tool, call.arguments);
    if (sensitive) {
      return {
        allowed: false,
        reason: `Protected resource requires explicit access: ${sensitive}`,
      };
    }

    if (tool.name === "bash") return this.evaluateShell(call.arguments);
    if (tool.effect === "read" || tool.name === "git_status" || tool.name === "git_diff") {
      return { allowed: true, reason: "Read-only workspace operation" };
    }
    if (this.mode === "full-auto") return { allowed: true, reason: "Full-auto mode" };
    if (this.mode === "auto-edit" && tool.effect === "write") {
      return { allowed: true, reason: "Workspace edit allowed by auto-edit mode" };
    }
    if (this.mode === "deny") return { allowed: false, reason: "Side effects disabled" };
    return { allowed: false, reason: "Explicit approval required" };
  }

  async authorize(
    tool: ToolDefinition,
    call: AgentToolCall,
    notify?: (request: PermissionRequest) => void | Promise<void>,
  ): Promise<PermissionDecision> {
    const decision = this.evaluate(tool, call);
    if (decision.allowed) return decision;
    const shellRisk = tool.name === "bash" ? classifyShell(call.arguments.command) : undefined;
    if (shellRisk?.risk === "critical") return decision;
    if (this.mode !== "ask" || !this.options.approve) return decision;
    const request: PermissionRequest = {
      tool,
      arguments: call.arguments,
      reason: decision.reason,
      risk: shellRisk?.risk ?? (tool.effect === "write" ? "medium" : "high"),
    };
    await notify?.(request);
    const allowed = await this.options.approve(request);
    return {
      allowed,
      reason: allowed ? "Approved by user" : "Denied by user",
    };
  }

  private evaluateShell(argumentsValue: Record<string, unknown>): PermissionDecision {
    const command = argumentsValue.command;
    if (typeof command !== "string" || !command.trim()) {
      return { allowed: false, reason: "Shell command must be a non-empty string" };
    }
    const protectedReference = this.protectedPaths.find((path) =>
      commandReferencesPath(command, path),
    );
    if (protectedReference) {
      return {
        allowed: false,
        reason: `Shell command references protected resource: ${protectedReference}`,
      };
    }
    const classification = classifyShell(command);
    if (classification.risk === "critical") {
      return { allowed: false, reason: `Critical shell command blocked: ${classification.reason}` };
    }
    if (classification.risk === "low") {
      return { allowed: true, reason: classification.reason };
    }
    if (this.mode === "full-auto" && classification.risk !== "high") {
      return { allowed: true, reason: "Full-auto mode allows non-critical command" };
    }
    if (
      this.mode === "auto-edit" &&
      this.options.projectTrusted &&
      TRUSTED_PROJECT_COMMAND.test(command)
    ) {
      return { allowed: true, reason: "Trusted project verification command" };
    }
    if (this.mode === "deny") return { allowed: false, reason: "Shell execution disabled" };
    return { allowed: false, reason: classification.reason };
  }

  private sensitiveResource(
    tool: ToolDefinition,
    argumentsValue: Record<string, unknown>,
  ): string | undefined {
    if (tool.name === "apply_patch") {
      const patch = argumentsValue.patch;
      if (typeof patch !== "string") return undefined;
      const paths = [...patch.matchAll(/^(?:\+\+\+|---)\s+(?:[ab]\/)?([^\t\n]+)$/gm)].map((match) =>
        normalizeRelativePath(match[1]!),
      );
      return this.protectedPaths.find((protectedPath) =>
        paths.some((path) => path === protectedPath || path.startsWith(`${protectedPath}/`)),
      );
    }
    if (!["read", "write", "edit", "git_diff"].includes(tool.name)) return undefined;
    const rawPath = argumentsValue.path;
    if (typeof rawPath !== "string") return undefined;
    const normalized = normalizeRelativePath(rawPath);
    return this.protectedPaths.find(
      (protectedPath) => normalized === protectedPath || normalized.startsWith(`${protectedPath}/`),
    );
  }
}

export function classifyShell(commandValue: unknown): {
  risk: "low" | "medium" | "high" | "critical";
  reason: string;
} {
  if (typeof commandValue !== "string" || !commandValue.trim()) {
    return { risk: "high", reason: "Invalid shell command" };
  }
  const command = commandValue.trim();
  for (const [pattern, reason] of CRITICAL_SHELL_PATTERNS) {
    if (pattern.test(command)) return { risk: "critical", reason };
  }
  for (const [pattern, reason] of HIGH_RISK_SHELL_PATTERNS) {
    if (pattern.test(command)) return { risk: "high", reason };
  }
  if (
    READ_ONLY_SHELL.some((pattern) => pattern.test(command)) &&
    !/[>|;&]/.test(command) &&
    !/(?:^|\s)(?:\/|~\/|\$HOME\/)/.test(command)
  ) {
    return { risk: "low", reason: "Recognized read-only command" };
  }
  if (TRUSTED_PROJECT_COMMAND.test(command)) {
    return { risk: "medium", reason: "Project command can execute repository-controlled code" };
  }
  return { risk: "medium", reason: "General shell command requires approval" };
}

function commandReferencesPath(command: string, path: string): boolean {
  const escaped = path.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`(?:^|[\\s'\"/])${escaped}(?:[\\s'\"/]|$)`).test(command.replaceAll("\\", "/"));
}

export function displayWorkspacePath(cwd: string, path: string): string {
  const candidate = resolve(cwd, path);
  const rel = relative(resolve(cwd), candidate);
  return rel.split(sep).join("/");
}
