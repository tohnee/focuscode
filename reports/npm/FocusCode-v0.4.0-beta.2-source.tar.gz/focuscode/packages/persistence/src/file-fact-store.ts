import { constants } from "node:fs";
import {
  access,
  appendFile,
  mkdir,
  open,
  readFile,
  readdir,
  rename,
  unlink,
  writeFile,
} from "node:fs/promises";
import { join } from "node:path";
import {
  DomainEventSchema,
  KernelCheckpointSchema,
  assertSchema,
  newId,
  sha256Digest,
  type AppendAckV1,
  type AppendRequestV1,
  type DomainEventV1,
  type FactPort,
  type KernelCheckpointV1,
} from "@focuscode/contracts";

const TASK_ID = /^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,127}$/;

function assertTaskId(taskId: string): void {
  if (!TASK_ID.test(taskId)) throw new Error(`Unsafe task id: ${taskId}`);
}

async function exists(path: string): Promise<boolean> {
  try {
    await access(path, constants.F_OK);
    return true;
  } catch {
    return false;
  }
}

export class VersionConflictError extends Error {
  constructor(
    readonly expected: number,
    readonly actual: number,
  ) {
    super(`Event version conflict: expected ${expected}, actual ${actual}`);
    this.name = "VersionConflictError";
  }
}

export class FileFactStore implements FactPort {
  constructor(readonly rootDirectory: string) {}

  private taskDirectory(taskId: string): string {
    assertTaskId(taskId);
    return join(this.rootDirectory, "tasks", taskId);
  }

  private async withTaskLock<T>(taskId: string, operation: () => Promise<T>): Promise<T> {
    const directory = this.taskDirectory(taskId);
    await mkdir(directory, { recursive: true });
    const lockPath = join(directory, ".append.lock");
    let handle: Awaited<ReturnType<typeof open>> | undefined;
    for (let attempt = 0; attempt < 200; attempt += 1) {
      try {
        handle = await open(lockPath, "wx", 0o600);
        break;
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
        await new Promise((resolve) => setTimeout(resolve, 10));
      }
    }
    if (!handle) throw new Error(`Timed out acquiring event lock for ${taskId}`);
    try {
      return await operation();
    } finally {
      await handle.close();
      await unlink(lockPath).catch(() => undefined);
    }
  }

  async append(request: AppendRequestV1): Promise<AppendAckV1> {
    if (request.events.length === 0) {
      return { firstSeq: request.expectedVersion, lastSeq: request.expectedVersion, events: [] };
    }
    return this.withTaskLock(request.taskId, async () => {
      const existing = await this.loadEvents(request.taskId);
      if (existing.length !== request.expectedVersion) {
        throw new VersionConflictError(request.expectedVersion, existing.length);
      }
      const committed = request.events.map((event, offset): DomainEventV1 => {
        if (event.taskId !== request.taskId) {
          throw new Error(`Event ${event.eventId} belongs to a different task`);
        }
        const eventWithoutDigest = { ...event, seq: request.expectedVersion + offset + 1 };
        const committedEvent = {
          ...eventWithoutDigest,
          digest: sha256Digest(eventWithoutDigest),
        };
        assertSchema(DomainEventSchema, committedEvent, "domain event");
        return committedEvent;
      });
      const eventPath = join(this.taskDirectory(request.taskId), "events.jsonl");
      await appendFile(
        eventPath,
        `${committed.map((event) => JSON.stringify(event)).join("\n")}\n`,
        {
          encoding: "utf8",
          mode: 0o600,
        },
      );
      return {
        firstSeq: committed[0]?.seq ?? request.expectedVersion,
        lastSeq: committed.at(-1)?.seq ?? request.expectedVersion,
        events: committed,
      };
    });
  }

  async loadEvents(taskId: string, afterSeq = 0): Promise<DomainEventV1[]> {
    const path = join(this.taskDirectory(taskId), "events.jsonl");
    if (!(await exists(path))) return [];
    const text = await readFile(path, "utf8");
    const events = text
      .split("\n")
      .filter(Boolean)
      .map((line, index) => {
        const event: unknown = JSON.parse(line);
        assertSchema(DomainEventSchema, event, `event line ${index + 1}`);
        return event;
      });
    return events.filter((event) => event.seq > afterSeq);
  }

  async loadCheckpoint(taskId: string): Promise<KernelCheckpointV1 | undefined> {
    const path = join(this.taskDirectory(taskId), "checkpoint.json");
    if (!(await exists(path))) return undefined;
    const checkpoint: unknown = JSON.parse(await readFile(path, "utf8"));
    assertSchema(KernelCheckpointSchema, checkpoint, "kernel checkpoint");
    return checkpoint;
  }

  async saveCheckpoint(checkpoint: KernelCheckpointV1): Promise<void> {
    assertSchema(KernelCheckpointSchema, checkpoint, "kernel checkpoint");
    const directory = this.taskDirectory(checkpoint.taskId);
    await mkdir(directory, { recursive: true });
    const target = join(directory, "checkpoint.json");
    const temporary = join(directory, `checkpoint.${newId("tmp")}.json`);
    await writeFile(temporary, `${JSON.stringify(checkpoint, null, 2)}\n`, {
      encoding: "utf8",
      mode: 0o600,
    });
    await rename(temporary, target);
  }

  async listTaskIds(): Promise<string[]> {
    const directory = join(this.rootDirectory, "tasks");
    if (!(await exists(directory))) return [];
    return (await readdir(directory, { withFileTypes: true }))
      .filter((entry) => entry.isDirectory() && TASK_ID.test(entry.name))
      .map((entry) => entry.name)
      .sort();
  }
}
