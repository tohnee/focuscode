import { describe, expect, it } from "vitest";
import { newId, type NewDomainEventV1 } from "@focuscode/contracts";
import { createTestDirectory } from "@focuscode/testkit";
import { FileFactStore, VersionConflictError } from "../src/index.js";

describe("FileFactStore", () => {
  it("appends with optimistic versions and reloads canonical events", async () => {
    const root = await createTestDirectory("facts");
    const store = new FileFactStore(root);
    const event: NewDomainEventV1 = {
      schemaVersion: "domain-event.v1",
      eventId: newId("evt"),
      taskId: "task-1",
      kind: "FixtureCreated",
      at: "2026-07-19T00:00:00.000Z",
      actor: { id: "tester", kind: "user" },
      payload: { value: 1 },
    };
    const ack = await store.append({ taskId: "task-1", expectedVersion: 0, events: [event] });
    expect(ack.lastSeq).toBe(1);
    expect(ack.events[0]?.digest).toMatch(/^sha256:/);
    await expect(
      store.append({
        taskId: "task-1",
        expectedVersion: 0,
        events: [{ ...event, eventId: newId("evt") }],
      }),
    ).rejects.toBeInstanceOf(VersionConflictError);
    expect(await store.loadEvents("task-1")).toEqual(ack.events);
    expect(await store.listTaskIds()).toEqual(["task-1"]);
  });

  it("rejects unsafe task ids before touching the filesystem", async () => {
    const store = new FileFactStore(await createTestDirectory("unsafe-id"));
    await expect(store.loadEvents("../../escape")).rejects.toThrow(/Unsafe task id/);
  });
});
