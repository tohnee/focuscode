import { normalizeRelativePath, type ActionIntentV1, type ToolSpecV1 } from "@focuscode/contracts";
import type { EffectLedgerSnapshot } from "./effect-ledger.js";

export type PolicyDisposition = "grant" | "approval_required" | "deny";

export interface PolicyDecision {
  disposition: PolicyDisposition;
  reason: string;
  riskScore: number;
}

export interface PolicyConfig {
  protectedPaths: string[];
  maxChangedFiles: number;
  maxChangedLines: number;
  maxRiskScore: number;
  allowNetwork: boolean;
  allowSecrets: boolean;
  autoGrantRegisteredCommands: boolean;
  autoGrantSafeWrites: boolean;
}

export interface ApprovalRequest {
  intent: ActionIntentV1;
  tool: ToolSpecV1;
  reason: string;
  currentLedger: EffectLedgerSnapshot;
  projectedRiskScore: number;
}

export interface ApprovalPort {
  request(request: ApprovalRequest): Promise<boolean>;
}

export class PolicyEngine {
  constructor(private readonly config: PolicyConfig) {}

  evaluate(
    intent: ActionIntentV1,
    tool: ToolSpecV1,
    ledger: EffectLedgerSnapshot,
    projectedRiskScore: number,
  ): PolicyDecision {
    const effectClasses = new Set(intent.expectedEffects.map((effect) => effect.class));
    const unadvertised = [...effectClasses].filter(
      (effectClass) => !tool.effectClasses.includes(effectClass),
    );
    if (unadvertised.length > 0) {
      return {
        disposition: "deny",
        reason: `Intent claims effects not declared by tool: ${unadvertised.join(", ")}`,
        riskScore: projectedRiskScore,
      };
    }

    const path = readPathArgument(intent.arguments);
    if (path && this.isProtected(path)) {
      return {
        disposition: "deny",
        reason: `Protected path is outside this task's write capability: ${path}`,
        riskScore: projectedRiskScore,
      };
    }
    if (effectClasses.has("network") && !this.config.allowNetwork) {
      return {
        disposition: "deny",
        reason: "Network effects are disabled by the policy snapshot",
        riskScore: projectedRiskScore,
      };
    }
    if (effectClasses.has("secret") && !this.config.allowSecrets) {
      return {
        disposition: "deny",
        reason: "Secret capabilities are not available in the local alpha runtime",
        riskScore: projectedRiskScore,
      };
    }
    if (projectedRiskScore > this.config.maxRiskScore) {
      return {
        disposition: "deny",
        reason: `Cumulative risk ${projectedRiskScore} exceeds ${this.config.maxRiskScore}`,
        riskScore: projectedRiskScore,
      };
    }
    if (ledger.changedFiles.length >= this.config.maxChangedFiles) {
      return {
        disposition: "deny",
        reason: `Changed-file budget ${this.config.maxChangedFiles} has been exhausted`,
        riskScore: projectedRiskScore,
      };
    }
    if (ledger.changedLines >= this.config.maxChangedLines) {
      return {
        disposition: "deny",
        reason: `Changed-line budget ${this.config.maxChangedLines} has been exhausted`,
        riskScore: projectedRiskScore,
      };
    }

    if (tool.id === "run_registered_command" && this.config.autoGrantRegisteredCommands) {
      return {
        disposition: "grant",
        reason: "Command is owner-registered and allowed by this execution profile",
        riskScore: projectedRiskScore,
      };
    }
    if (tool.id === "apply_edit_ir" && this.config.autoGrantSafeWrites) {
      return {
        disposition: "grant",
        reason: "Bounded edit is auto-granted by this task's explicit execution profile",
        riskScore: projectedRiskScore,
      };
    }
    if (tool.id === "apply_edit_ir" || effectClasses.has("command") || effectClasses.has("git")) {
      return {
        disposition: "approval_required",
        reason: "This action changes workspace state or starts a process",
        riskScore: projectedRiskScore,
      };
    }
    return {
      disposition: "grant",
      reason: "Read-only action is within the current capability envelope",
      riskScore: projectedRiskScore,
    };
  }

  private isProtected(path: string): boolean {
    const normalized = normalizeRelativePath(path);
    return this.config.protectedPaths.some((entry) => {
      const protectedPath = normalizeRelativePath(entry);
      return normalized === protectedPath || normalized.startsWith(`${protectedPath}/`);
    });
  }
}

function readPathArgument(value: unknown): string | undefined {
  if (!value || typeof value !== "object") return undefined;
  const path = (value as Record<string, unknown>).path;
  return typeof path === "string" ? path : undefined;
}
