import { describe, expect, it } from "vitest";
import {
  FakeEffectPort,
  InMemoryFactStore,
  ScriptedDecisionPort,
  StaticVerifier,
  fixtureExecution,
  fixtureModel,
  fixtureTask,
  fixtureTool,
} from "@focuscode/testkit";
import { FocusKernel, assertTransition } from "../src/index.js";

describe("FocusKernel", () => {
  it("executes decision -> effect -> verification and stops at REVIEW_READY", async () => {
    const facts = new InMemoryFactStore();
    const effects = new FakeEffectPort();
    const tool = fixtureTool();
    const decision = new ScriptedDecisionPort([
      {
        kind: "tool_intent_template",
        intents: [
          {
            toolId: tool.id,
            arguments: { path: "src/value.ts" },
            expectedEffects: [
              { class: "read", resource: "src/value.ts", description: "Inspect value" },
            ],
            justification: "Need evidence",
          },
        ],
      },
      { kind: "completion_candidate", summary: "ready", evidence: [], residualRisks: [] },
    ]);
    const kernel = new FocusKernel({
      decision,
      effects,
      facts,
      verifier: new StaticVerifier("PASS", "PASS"),
      tools: [tool],
      workerId: "worker-1",
    });
    const result = await kernel.run({
      task: fixtureTask(),
      execution: fixtureExecution(),
      model: fixtureModel(),
    });
    expect(result.checkpoint.state).toBe("REVIEW_READY");
    expect(result.checkpoint.turn).toBe(2);
    expect(result.checkpoint.actionCount).toBe(1);
    expect(effects.submitted).toHaveLength(1);
    expect(result.verification?.conclusion).toBe("PASS");
    expect(result.events.map((event) => event.kind)).toContain("VerificationCompleted");

    const eventCount = result.events.length;
    const resumed = await kernel.run({
      task: fixtureTask(),
      execution: fixtureExecution(),
      model: fixtureModel(),
    });
    expect(resumed.events).toHaveLength(eventCount);
  });

  it("rejects a truncated turn with zero effects", async () => {
    const facts = new InMemoryFactStore();
    const effects = new FakeEffectPort();
    const kernel = new FocusKernel({
      decision: new ScriptedDecisionPort([
        { kind: "fault", status: "truncated", message: "connection closed" },
      ]),
      effects,
      facts,
      verifier: new StaticVerifier(),
      tools: [fixtureTool()],
      workerId: "worker-1",
    });
    const result = await kernel.run({
      task: fixtureTask(),
      execution: fixtureExecution("truncated-task"),
      model: fixtureModel(),
    });
    expect(result.checkpoint.state).toBe("BLOCKED");
    expect(effects.submitted).toEqual([]);
    expect(result.events.map((event) => event.kind)).not.toContain("ActionRequested");
  });

  it("does not convert a completion candidate into success when verification regresses", async () => {
    const kernel = new FocusKernel({
      decision: new ScriptedDecisionPort([
        { kind: "completion_candidate", summary: "claims done", evidence: [], residualRisks: [] },
      ]),
      effects: new FakeEffectPort(),
      facts: new InMemoryFactStore(),
      verifier: new StaticVerifier("PASS", "REGRESSION"),
      tools: [],
      workerId: "worker-1",
    });
    const result = await kernel.run({
      task: fixtureTask(),
      execution: fixtureExecution("regression-task"),
      model: fixtureModel(),
    });
    expect(result.checkpoint.state).toBe("BLOCKED");
    expect(result.verification?.conclusion).toBe("REGRESSION");
  });

  it("enforces state-machine transitions", () => {
    expect(() => assertTransition("CREATED", "PREFLIGHT")).not.toThrow();
    expect(() => assertTransition("CREATED", "ACCEPTED")).toThrow(/Invalid kernel transition/);
  });
});
