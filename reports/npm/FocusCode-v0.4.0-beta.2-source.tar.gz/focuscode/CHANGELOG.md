# Changelog

## 0.4.0-beta.2 — 2026-07-20

Hardened protected-path enforcement across both policy layers and shipped the default audited-kernel
Model Pack inside the published tarball.

### Added

- `normalizeRelativePath` in `@focuscode/contracts`: unifies separators, drops `.` segments and
  collapses `..` segments so disguised paths such as `src/../.env`, `src/sub/../../.env` and
  `src\..\.env` can no longer bypass protected-path matching;
- protected-path normalization is now applied consistently in the Kernel `PolicyEngine`
  (`action-domain`) and the conversational `PermissionController` (`agent-runtime`), including
  `apply_patch` target files extracted from patch headers;
- the default `generic-openai` Model Pack is bundled into `@focuscode/cli`
  (`files: ["bundle", "model-packs", ...]`), so the audited-kernel path
  (`focuscode run`) works from the clean-installed tarball without a repository checkout;
- `npm:verify` now also exercises a clean-installed audited-kernel run with the bundled Model Pack.

### Verified

- 23 workspace projects build;
- 26 test files and 93 tests pass (new path-disguise and Model-Pack coverage);
- Statements 77.53% / Branches 65.24% / Functions 82.75% / Lines 81.85%;
- architecture and formatting gates pass;
- npm release verification performs a clean install plus a streaming tool loop and an audited-kernel
  run against the bundled Model Pack.

### Remaining release gates

- unchanged from beta.1: live provider contracts, real Docker/runsc/VM adversarial CI, Pi same-model
  benchmark, capability-contained extensions, session WAL/recovery, single policy path, production
  OIDC/RBAC, secret/egress broker, HA share persistence and operations SLOs.

## 0.4.0-beta.1 — 2026-07-19

Apple-to-Apple reviewed the complete v0.3 Alpha implementation against Pi `0.80.10` and hardened
the CLI path for model portability and enterprise deployment.

### Added

- first-class Kimi/Moonshot, Qwen China/International, GLM/ZAI China/Global, DeepSeek and MiniMax
  China/Global provider profiles, plus per-model capability/compatibility/reliability overrides;
- Qwen/ZAI/DeepSeek reasoning dialects, assistant reasoning replay, tool-stream compatibility,
  conditional request fields, bounded retry/Retry-After handling and retry lifecycle events;
- OIDC discovery, token endpoint auth-method negotiation and OAuth token revocation;
- validated custom TUI theme and animated mascot JSON, configurable title and differential frame
  updates;
- append, interrupt and follow-up mid-turn queues across TUI, RPC and SDK;
- HMAC-SHA-256 chained, content-minimizing enterprise audit journals with offline verification;
- enterprise provider/model/extension allowlists, signed-extension enforcement, remote-media denial,
  isolated-executor enforcement and a `focuscode doctor` readiness command;
- digest-pinned container policy, `--pull never`, IPC/log isolation and explicit isolation health;
- share-server signer allowlists, maximum age, authentication fail-closed mode and rate limiting.

### Verified

- 23 workspace projects build;
- 26 test files and 89 tests pass;
- architecture and formatting gates pass;
- npm release verification performs a clean install and full local streaming tool loop.

### Remaining release gates

- live contract tests with credentials for each named provider and pinned model revision;
- real Docker/runsc and disposable-VM adversarial CI on target infrastructure;
- Pi same-model/same-budget repository benchmark;
- capability-contained extension execution, session WAL/recovery, and a single policy path shared by
  the conversational Agent and deterministic Focus Kernel;
- production OIDC/RBAC, secret/egress broker, HA share persistence and operations SLOs.

## 0.3.0-alpha.1 — 2026-07-19

Completed the next Harness product slice across CLI, SDK, infrastructure, tests and documentation.

### Added

- OAuth 2.0 Authorization Code + PKCE, loopback callback, Device Authorization, refresh and an
  AES-256-GCM multi-account credential store;
- native OpenAI Responses and Google Gemini clients alongside OpenAI Chat and Anthropic Messages;
- full-screen raw-terminal TUI, five themes, configurable keymap and six animated mascots;
- PNG/JPEG/WebP/GIF input through CLI, TUI, RPC and SDK with runtime validation and four-provider
  mappings;
- bounded append/interrupt mid-turn steering with generation-only cancellation and recovery;
- npm extension pack/install/list/remove, signature/integrity checks, permission manifest and lock;
- Ed25519 session sharing, default redaction, import/publish/download and an immutable reference
  share server;
- hardened Docker, gVisor and strict SSH VM/microVM executors with secure auto selection;
- standalone publish-ready `@focuscode/cli` npm bundle and clean-install coding-loop verification;
- example extension, deployment infrastructure and focused architecture/operations documentation.

### Hardened

- default Sandbox is now gVisor → Docker → fail, with no silent Host fallback;
- SDK honors the same Sandbox and extension signature policy as the CLI;
- RPC and stored images validate base64, size, MIME, magic bytes and digest;
- share server cryptographically verifies bundles instead of checking signature fields;
- extension install failures roll back and unsigned locks are blocked again at load time;
- Docker timeout/abort force-removes the uniquely named container;
- TUI handles cross-chunk bracketed paste, visible cursor and terminal-control injection;
- steering handles custom providers that throw on AbortSignal and avoids receipt-size races;
- Agent config validates protocols, auth, URLs, sandbox/VM settings and keymaps at runtime.

### Known limitations

- the delivery host has no Docker/runsc/Firecracker/QEMU, so physical isolation was not executed
  locally; driver and invocation contracts are tested;
- extensions are still trusted in-process Node.js code, not capability-contained;
- Session JSONL and conversational Tool effects do not yet provide WAL/unknown-effect recovery;
- share server lacks organization identity, ACL, TTL, deletion and abuse controls;
- no real-repository same-model benchmark proves superiority over Pi or other agents.

## 0.2.0-alpha.1 — 2026-07-19

Added the complete conversational CLI coding-agent path while retaining the audited task Kernel.

### Added

- streaming OpenAI Chat Completions and Anthropic Messages clients with native tool calling;
- model-portable native, prompt-JSON and automatic tool modes;
- ten coding tools: read, write, exact edit, apply patch, grep, find, ls, shell, git status and diff;
- interactive, print, JSON event stream, JSON-RPC and TypeScript SDK entrypoints;
- append-only JSONL sessions with active-branch tree, resume, fork, compaction and HTML export;
- AGENTS instructions, skills, prompt templates and hot-reloadable JavaScript extensions;
- provider presets for API and local OpenAI-compatible endpoints;
- permission modes, protected path checks, shell risk classification and child-environment secret scrubbing;
- deterministic CLI agent demo and real process-level streaming/tool-call E2E tests;
- Pi capability baseline, CLI architecture, onboarding and updated threat model.

### Known limitations

- host process execution only; no container/microVM network or filesystem isolation;
- no OAuth subscriptions, OpenAI Responses/Gemini-native clients, images or remote model catalog;
- lightweight readline UI, not a full component/theme/keybinding TUI;
- no extension package manager/signature ecosystem;
- no mid-turn steering queue; abort and subsequent prompt are supported;
- CLI Session effects are not backed by a durable receipt/reconciliation journal.

## 0.1.0-alpha.1 — 2026-07-19

Initial executable Harness Alpha derived from the FocusCode product, architecture and engineering
plans.

### Added

- Canonical contracts and generated JSON Schemas;
- Focus Kernel with Atomic Turn and deterministic verification gate;
- declarative Model Pack and OpenAI-compatible transport;
- Scripted Model for deterministic protocol/E2E tests;
- Context Compiler and stable prefix digest;
- Policy, Capability Grant construction, Effect Receipt and Effect Ledger;
- bounded local read/edit/registered-command tools;
- File FactStore, Memory proposal/acceptance and portable export;
- CLI, SDK, read-only Control API and Action Runtime manifest process;
- ACP/MCP/A2A/Capsule boundary utilities;
- architecture, onboarding, progress, security and test documentation;
- 33 tests and enforced coverage floors.

### Known limitations

- local process guard only; no production physical sandbox;
- File persistence only; no PostgreSQL/WAL/outbox/unknown-effect recovery;
- Generic Pack only; no formally certified open-model Pack;
- protocol modules are contract-level, not authenticated network gateways;
- no VS Code client, multi-agent write path, Secret Broker or Egress Broker.
