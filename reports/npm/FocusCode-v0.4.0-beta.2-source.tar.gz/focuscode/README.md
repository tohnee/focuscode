# FocusCode CLI Coding Agent

FocusCode `0.4.0-beta.1` 是一个模型之上的、用户可控且可迁移的 Coding Agent Harness。
本版本把 Kimi、Qwen、GLM、DeepSeek、MiniMax 的模型方言、OIDC/OAuth、全屏 TUI 与六只动态
终端伙伴、图片输入、扩展与签名会话分享、三类 mid-turn queue、Docker/gVisor/VM 隔离、
企业允许列表和防篡改审计接入同一条 CLI/SDK 可运行链路。

它不是某家模型的薄包装。Provider、上下文、会话、工具、权限、执行隔离与扩展资产都有
稳定边界；更换模型不会丢失本地会话与 Harness 资产。Beta 表示接口与安全边界仍可能演进，
也不表示已经在真实任务基准上优于 Pi、Claude Code、Codex 或其他主流 Coding Agent。

## 本阶段能力

| 能力              | 已实现的可执行结果                                                                                                                                     |
| ----------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
| OAuth / Provider  | PKCE/device/OIDC/refresh/revoke、AES-256-GCM 凭据库；五系 11 个区域 Profile、四协议、reasoning/Tool continuation、Retry-After 和模型级覆盖             |
| 全屏 TUI          | alternate screen、差分刷新、流式输出、审批/历史/滚动/粘贴、可配置快捷键、5 主题、6 伙伴，以及经过校验的自定义主题/动画助手 JSON                        |
| 图片输入          | PNG/JPEG/WebP/GIF，本地或 HTTPS；CLI/TUI/RPC/SDK；内容验证、Session 持久化、模型能力 Gate；企业模式默认禁止远程 URL                                    |
| 扩展与分享        | npm pack/install/list/remove、禁 lifecycle scripts、registry signature check、权限声明、锁文件；Ed25519 签名分享、脱敏、导入、发布、下载与参考分享服务 |
| Mid-turn steering | 有界 FIFO；append、generation-only interrupt、final-response 后 follow-up；TUI、RPC、SDK 语义一致                                                      |
| 真实隔离          | 默认 `auto`：gVisor → Docker → fail；企业模式强制非 Host、镜像 digest、`--pull never`；另有严格 SSH disposable-VM adapter                              |
| npm 发布          | `@focuscode/cli` 独立 ESM bundle、全局 bin、clean-install 验证、真实本地 SSE tool-loop 验收与发布清单                                                  |

## 安装

从交付的 npm tarball 安装不需要 pnpm 或 monorepo：

```bash
npm install --global ./focuscode-cli-0.4.0-beta.1.tgz
focuscode --version
focuscode --help
```

拥有 npm scope 发布权限后：

```bash
npm publish ./focuscode-cli-0.4.0-beta.1.tgz --access public --provenance
npm install --global @focuscode/cli@0.4.0-beta.1
```

从源码开发：

```bash
corepack enable
corepack prepare pnpm@11.7.0 --activate
pnpm install --frozen-lockfile
pnpm verify
pnpm agent:demo
pnpm npm:verify
```

需要 Node.js `>=22.12.0`。`agent:demo` 使用本地确定性 SSE Provider，真实执行两轮模型调用
和一次文件写入，不需要外部 API Key。

## 第一次运行

API Provider：

```bash
export OPENAI_API_KEY=...
focuscode --model openai/gpt-5 --approval ask

export ANTHROPIC_API_KEY=...
focuscode --model anthropic/claude-model-id --approval ask

export GEMINI_API_KEY=...
focuscode --model gemini/gemini-model-id --approval ask

export MOONSHOT_API_KEY=...
focuscode --provider kimi --approval ask

export DASHSCOPE_API_KEY=...
focuscode --provider qwen --approval ask

export ZAI_API_KEY=...
focuscode --provider glm --approval ask

export DEEPSEEK_API_KEY=...
focuscode --provider deepseek --approval ask

export MINIMAX_API_KEY=...
focuscode --provider minimax --approval ask
```

本地 OpenAI-compatible Provider：

```bash
focuscode --provider ollama --model qwen3-coder \
  --sandbox docker --approval ask
```

默认沙箱是 `auto`、默认容器断网、默认不允许回退。如果机器没有 Docker/gVisor，可在完全
理解风险后显式使用 `--sandbox host`；CLI 会打印警告。先检查运行时：

```bash
focuscode sandbox doctor --kind auto
focuscode sandbox doctor --kind gvisor
```

## OAuth

Google 与 GitHub 有内置 Profile，标准企业身份服务可通过 OIDC discovery；其他 OAuth 2.0
Provider 也可显式配置端点：

```bash
export FOCUSCODE_GOOGLE_CLIENT_ID=...
focuscode auth login google --device --account default
focuscode auth list

focuscode auth login enterprise \
  --issuer https://identity.example.com \
  --client-id "$FOCUSCODE_ENTERPRISE_CLIENT_ID" \
  --scope openid,profile,offline_access,models

focuscode auth login private-provider \
  --client-id "$FOCUSCODE_PRIVATE_PROVIDER_CLIENT_ID" \
  --authorization-url https://id.example.com/oauth/authorize \
  --token-url https://id.example.com/oauth/token \
  --scope models,offline_access

focuscode --provider private-provider --model model-id \
  --protocol openai-responses --oauth-account default
```

Client Secret 建议放在 `FOCUSCODE_<PROVIDER>_CLIENT_SECRET`，不要写入项目配置或命令历史。

## TUI、图片与 steering

TTY 中默认进入全屏 TUI：

```bash
focuscode --model openai/gpt-5 --theme candy --mascot pico
focuscode --theme .focuscode/team-theme.json --mascot .focuscode/team-mascot.json
focuscode --model anthropic/claude-model-id -i ./screen.png "按截图修复布局"
focuscode mascots
focuscode themes
```

运行中直接提交新文字会排入 append steering；需要立即改变当前生成方向时使用
`/interrupt <instruction>`；需要当前响应完成后再追加工作时使用 `/followup <instruction>`。
`/image <path-or-url>` 给下一条消息添加图片。常用命令包括
`/status`、`/tools`、`/compact`、`/sessions`、`/resume`、`/fork`、`/model`、
`/approval`、`/image`、`/reload` 和 `/export`。

快捷键可写入 `.focuscode/agent.json`，也可用 `--keymap keymap.json` 覆盖：

```json
{
  "schemaVersion": "focuscode-agent.v1",
  "tui": {
    "enabled": true,
    "theme": "aurora",
    "mascot": "mochi",
    "keymap": { "ctrl+x": "abort", "ctrl+g": "cycle_mascot" }
  }
}
```

## 扩展与会话分享

```bash
focuscode extension pack examples/extension-hello --out ./dist
focuscode extension install ./dist/focuscode-example-hello-extension-0.1.0.tgz \
  --allow-unsigned
focuscode extension list

focuscode share export --session SESSION_ID --out review.focuscode-share.json
focuscode share import review.focuscode-share.json --repo /path/to/repo
```

默认分享会移除工具输出、图片二进制和常见凭据。只有明确指定
`--include-tool-output` / `--include-images` 才会保留；导入前会验证 Ed25519 签名。签名证明
内容未被修改，不代表你信任签名者或其中的 Prompt。

## Monorepo

```text
apps/cli                  npm CLI 与 TUI/print/json/rpc 组合根
apps/share-server         不可变签名会话存储参考服务
apps/control-api          只读控制面入口
apps/action-runtime       工具清单与执行面边界
packages/agent-runtime    会话循环、Provider、工具、权限、Session、steering、multimodal
packages/auth             OAuth 2.0、PKCE/device/refresh、加密凭据库
packages/tui              全屏终端状态机、主题、快捷键与伙伴
packages/sandbox          Host/Docker/gVisor/SSH VM 执行器
packages/ecosystem        npm 扩展分发与 Ed25519 会话分享
packages/sdk              可嵌入 Coding Agent 与审计 Harness 组合 API
packages/harness-core     可恢复任务状态机与确定性完成 Gate
packages/model-gateway    Atomic Decision 与声明式 Model Pack
packages/action-*         Intent/Policy/Grant/Receipt 与受控 backend
packages/context-*        Canonical Context 与 Repo Profile
packages/persistence      append-only Fact/Checkpoint
packages/verifier-eval    baseline/target 验证
packages/asset-plane      Memory 与可移植资产
```

会话型 Coding Agent 与审计型 Focus Kernel 是两个组合策略：前者优化日常低延迟编程，后者
优化可重放、Effect Receipt 和确定性完成 Gate。Provider、TUI、OAuth、沙箱和生态都是端口
适配器，不进入核心决策内核。

## 企业模式

```bash
focuscode init --enterprise \
  --provider deepseek --model deepseek-v4-pro \
  --sandbox-image registry.example.com/focuscode/node22@sha256:<64-hex-digest>
export FOCUSCODE_AUDIT_HMAC_KEY="$(openssl rand -base64 48)"
focuscode doctor --repo .
```

企业模式会对 Provider/model/extension、远程图片、Sandbox 和审计 key fail closed。只有
`doctor` 返回 `"ready": true` 才应进入 smoke test；这不替代目标 Docker/runsc/VM 攻击验收。

## 验证与边界

```bash
pnpm build
pnpm lint
pnpm test
pnpm test:coverage
pnpm release:check
```

自动化覆盖四类原生协议、五系 Provider 方言、reasoning state 回放、OAuth/OIDC、图片验证、
三类 steering、全屏 TUI、自定义主题/伙伴、扩展签名策略、会话分享与服务器、沙箱命令契约、真实 Host
进程 timeout/abort、CLI 进程 E2E、SDK 和 npm clean install。

本仓库已实现 Docker/gVisor/VM 驱动与对抗性命令构造测试；是否真的获得物理隔离仍取决于
部署机安装并正确配置相应运行时。Host 模式不是安全沙箱。扩展仍是进程内可信代码，npm
签名与权限声明不是运行时 containment。详见 [SECURITY.md](SECURITY.md)。

## 文档

- [v0.4 Pi Apple-to-Apple 审查](docs/V0.4_PI_APPLE_TO_APPLE_REVIEW.md)
- [v0.4 企业接入与发布 Gate](docs/V0.4_ENTERPRISE_DEPLOYMENT.md)
- [v0.3 历史能力与架构](docs/V0.3_CAPABILITY_ARCHITECTURE.md)
- [OAuth 与 Provider](docs/OAUTH_AND_PROVIDERS.md)
- [TUI 与多模态](docs/TUI_AND_MULTIMODAL.md)
- [扩展与会话分享](docs/EXTENSIONS_AND_SHARING.md)
- [隔离与部署](docs/SANDBOXING.md)
- [npm 发布与安装](docs/NPM_RELEASE.md)
- [开发进度](docs/DEVELOPMENT_STATUS.md)
- [测试报告](docs/TEST_REPORT.md)
- [Pi 能力对照](docs/PI_PARITY.md)
- [一手实现参考](docs/REFERENCES.md)

## License

Apache-2.0。
