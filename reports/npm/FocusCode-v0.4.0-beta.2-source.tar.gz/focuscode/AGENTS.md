# AGENTS.md

Coding-agent harness (TypeScript, ESM). pnpm monorepo: `apps/*` (composition roots) + `packages/*` (libraries). Primary docs are in Chinese; README.md and docs/ are the source of truth for features.

## Environment

- Node `>=22.12.0` (CI pins 22.20.0), pnpm pinned to 11.7.0 via corepack: `corepack enable && corepack prepare pnpm@11.7.0 --activate`
- Install: `pnpm install --frozen-lockfile`

## Commands

- `pnpm verify` — the required local gate: boundary check + prettier check + build + tests with coverage
- `pnpm test` — builds first (`pnpm build && vitest run`); vitest runs against built `dist/`, so stale builds cause confusing failures
- Single test file: `pnpm build && npx vitest run packages/<pkg>/test/<file>.test.ts`
- Build one package: `pnpm --filter @focuscode/<pkg> build`
- `pnpm format` before finishing — lint includes `prettier --check .`
- Contract/schema changes in `packages/contracts`: also run `pnpm schemas` and commit regenerated `docs/schemas/`
- Full release gate (what CI runs): `pnpm release:check` = verify + demo + agent:demo + npm:verify

## Architecture boundaries (enforced by `scripts/check-boundaries.mjs` in `pnpm lint`)

Violating these fails lint — do not add imports across these lines:

- `contracts`: no imports from other `@focuscode/*` packages or provider SDKs
- `harness-core`: no `node:fs`, `node:child_process`, `fetch(`, action-backends, or model-gateway
- `agent-runtime`: no harness-core, model-gateway, persistence, sdk, auth, ecosystem, sandbox, tui, or apps
- `auth`, `ecosystem`, `sandbox`, `tui`: leaf adapters — no `@focuscode/*` imports at all
- Only `apps/*` and `packages/sdk` may compose the above

Two execution paths exist and must not be merged casually: the conversational agent (`packages/agent-runtime`, session/tool loop) and the audited kernel (`packages/harness-core`, Intent/Grant/Receipt/Verifier). See docs/ARCHITECTURE.md.

## Conventions

- Tests live in `packages/*/test/` and `apps/*/test/` (not colocated in `src/`); root `tests/` covers process entrypoints
- Coverage thresholds (statements 75 / branches 60 / functions 80 / lines 80) are floors, measured only on `packages/*/src` excluding `src/index.ts`
- CONTRIBUTING.md lists required test types per change (parser → differential/truncation tests, provider → SSE chunk tests, security → fail-closed tests, etc.) — follow it when touching those areas
- `SOURCE_MANIFEST.sha256` is a generated delivery artifact (`pnpm manifest`); regenerate it for release/delivery changes, not for everyday edits
- `reports/` (coverage, npm) is generated output
- Prettier config: printWidth 100, double quotes, trailing commas — run `pnpm format`, don't hand-format

## Docs

Authoritative deep-dives in `docs/`: ARCHITECTURE.md (two execution paths), DEVELOPMENT_STATUS.md, TEST_REPORT.md, SECURITY.md (trust boundaries: extensions are trusted in-process code, host sandbox is not a security boundary). Prefer these over guessing from filenames.
